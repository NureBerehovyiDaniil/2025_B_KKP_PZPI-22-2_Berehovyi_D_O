import { useEffect, useState } from "react";

export default function App() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");

  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [fileContent, setFileContent] = useState("");
  const [saving, setSaving] = useState(false);

  const [jsonFilename, setJsonFilename] = useState("text_final.json");

  const API_BASE = "http://localhost:4000";

  const fetchFiles = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/files`);
      if (!res.ok) throw new Error("Failed to fetch files from server.");
      const data = await res.json();
      setFiles(data);
    } catch (err) {
      console.error("Error fetching files:", err);
      setMessage("Failed to load file list.");
    }
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setMessage("");
  };

  const handleUpload = async () => {
  if (!file) {
    setMessage("Please select a file to upload.");
    return;
  }
  setUploading(true);
  setMessage("");

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch(`${API_BASE}/api/upload`, {
      method: "POST",
      body: formData,
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.detail || "Upload failed.");
    }

    const result = await res.json();
    setMessage(result.message || "Upload successful!");
    setFile(null);
    await fetchFiles();

    if (result.filename) {
      await loadFileContent(result.filename); // still loads for editing
    }
  } catch (err) {
    console.error("Error during upload:", err);
    setMessage(err.message || "Upload failed.");
  } finally {
    setUploading(false);
  }
};

  const loadFileContent = async (filename) => {
    try {
      const res = await fetch(`${API_BASE}/api/files/${filename}`);
      if (!res.ok) throw new Error("Failed to load file content from server.");

      const data = await res.json();
      setSelectedFile(filename);
      setTitle(data.title || "");
      setDescription(data.description || "");
      setFileContent(data.content || "");
      setMessage("");
    } catch (err) {
      console.error("Error loading file content:", err);
      setMessage("Failed to load file content.");
    }
  };

  const saveFileContent = async () => {
    if (!selectedFile) {
      setMessage("No file selected to save changes.");
      return;
    }
    setSaving(true);
    setMessage("");

    try {
      const res = await fetch(`${API_BASE}/api/files/${selectedFile}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, content: fileContent }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.detail || "Failed to save file changes.");
      }

      const result = await res.json();
      setMessage(result.message || "File changes saved successfully!");
    } catch (err) {
      console.error("Error saving file content:", err);
      setMessage(err.message || "Failed to save file changes.");
    } finally {
      setSaving(false);
    }
  };

  const saveAsJson = async () => {
    if (!jsonFilename) {
      setMessage("Filename for JSON export cannot be empty.");
      return;
    }
    setSaving(true);
    setMessage("");

    try {
      const res = await fetch(`${API_BASE}/api/save_json/${jsonFilename}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, content: fileContent }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.detail || "Failed to save JSON file.");
      }

      const result = await res.json();
      setMessage(result.message || "Content saved as text_final.txt!");
    } catch (err) {
      console.error("Error saving as JSON:", err);
      setMessage(err.message || "Failed to save file as text_final.txt.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 gap-4 p-4 max-w-3xl mx-auto font-sans">
      <h1 className="text-3xl font-extrabold text-gray-800 mb-6">File Uploader & Editor</h1>

      <div className="w-full bg-white p-6 rounded-xl shadow-lg flex flex-col gap-4">
        <h2 className="text-2xl font-semibold text-gray-700">Upload New File</h2>
        <div className="flex flex-col sm:flex-row gap-3 items-center">
          <input
            type="file"
            onChange={handleFileChange}
            className="flex-1 p-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
          <button
            onClick={handleUpload}
            disabled={!file || uploading}
            className={`px-6 py-2 rounded-lg text-white font-medium transition-all duration-300 ease-in-out
              ${uploading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700 shadow-md hover:shadow-lg"
              }`}
          >
            {uploading ? "Uploading..." : "Upload File"}
          </button>
        </div>
      </div>

      <div className="w-full bg-white p-6 rounded-xl shadow-lg mt-6">
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Available Text Files</h2>
        <ul className="border border-gray-300 rounded-lg p-3 w-full max-h-64 overflow-y-auto bg-gray-50">
          {files.length === 0 && <li className="text-gray-500 italic p-2">No files found. Upload one to start!</li>}
          {files.map((f) => (
            <li
              key={f}
              onClick={() => loadFileContent(f)}
              className={`cursor-pointer p-2 my-1 rounded-md transition-all duration-200 ease-in-out
                ${f === selectedFile
                  ? "bg-blue-100 text-blue-800 font-bold shadow-sm"
                  : "hover:bg-gray-200 text-gray-700"
                }`}
            >
              {f}
            </li>
          ))}
        </ul>
      </div>

      {selectedFile && (
        <div className="w-full mt-6 flex flex-col gap-5 bg-white p-6 rounded-xl shadow-lg">
          <h3 className="text-2xl font-semibold text-gray-700 border-b pb-3 mb-3">
            Editing: <span className="text-blue-600">{selectedFile}</span>
          </h3>

          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
          />

          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg h-24 resize-y focus:ring-blue-500 focus:border-blue-500 text-base"
          />

          <textarea
            placeholder="File content"
            className="w-full h-80 p-3 border border-gray-300 rounded-lg font-mono text-base resize-y focus:ring-blue-500 focus:border-blue-500"
            value={fileContent}
            onChange={(e) => setFileContent(e.target.value)}
          />

          <button
            onClick={saveFileContent}
            disabled={saving}
            className={`mt-3 px-6 py-3 rounded-lg text-white font-bold text-lg transition-all duration-300 ease-in-out
              ${saving
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-green-600 hover:bg-green-700 shadow-lg hover:shadow-xl"
              }`}
          >
            {saving ? "Saving..." : "Save Changes to json and txt"}
          </button>

          <div className="w-full mt-6 pt-6 border-t border-gray-200 flex flex-col gap-4">
            <h3 className="text-xl font-semibold text-gray-700">Export Current Content as <span className="text-purple-600">text_final.txt</span></h3>
            <p className="text-gray-600">
              This action will take the current Title, Description, and File Content from the editor
              and save it into a file named <code className="bg-gray-200 p-1 rounded font-mono text-sm">text_final.txt</code>
              in your backend's output directory.
            </p>
            <input
              type="text"
              placeholder="Enter a placeholder filename (e.g., export.json)"
              value={jsonFilename}
              onChange={(e) => setJsonFilename(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500 text-lg"
            />
            <button
              onClick={saveAsJson}
              disabled={saving}
              className={`mt-2 px-6 py-3 rounded-lg text-white font-bold text-lg transition-all duration-300 ease-in-out
                ${saving
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-purple-600 hover:bg-purple-700 shadow-lg hover:shadow-xl"
                }`}
            >
              {saving ? "Saving..." : "Save as text_final.txt"}
            </button>
          </div>
        </div>
      )}

      {message && (
        <p className="mt-6 text-center font-semibold text-white bg-red-500 p-4 rounded-xl shadow-lg animate-fade-in-down">
          {message}
        </p>
      )}
    </div>
  );
}
