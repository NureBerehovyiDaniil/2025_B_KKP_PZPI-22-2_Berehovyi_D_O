// src/components/FileUpload.jsx
import React, { useState } from "react";

const FileUpload = () => {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!file) return;

    // For local preview or processing
    const reader = new FileReader();
    reader.onload = () => {
      console.log("File content:", reader.result);
    };
    reader.readAsText(file); // or readAsDataURL / readAsArrayBuffer
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="file" onChange={handleFileChange} />
      <button type="submit">Upload</button>
    </form>
  );
};

export default FileUpload;
