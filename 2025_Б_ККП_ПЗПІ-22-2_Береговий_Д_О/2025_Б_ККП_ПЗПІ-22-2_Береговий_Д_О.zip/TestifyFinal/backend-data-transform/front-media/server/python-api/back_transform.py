import whisper
import fitz
from moviepy.video.io.VideoFileClip import VideoFileClip
import os
import time
import platform
import requests
import uuid
from requests.exceptions import RequestException, Timeout

# Directories
def is_wsl():
    return "microsoft" in platform.uname().release.lower()

if is_wsl():
    BASE_DIR = "/mnt/e/backend-data-transform/front-media/server/uploads"
else:
    BASE_DIR = r"E:\backend-data-transform\front-media\server\uploads"

OUTPUT_DIR = os.path.join(BASE_DIR, "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Utility Functions
def generate_unique_id():
    return str(uuid.uuid4())

def video_to_text(video_path, output_txt_path, model_name='base'):
    video = VideoFileClip(video_path)
    try:
        audio_path = os.path.join(OUTPUT_DIR, "temp_audio.wav")
        video.audio.write_audiofile(audio_path, logger=None)
        model = whisper.load_model(model_name)
        result = model.transcribe(audio_path)
        os.remove(audio_path)
        with open(output_txt_path, "w", encoding="utf-8") as f:
            f.write(result['text'])
    finally:
        video.close()
    return result['text']

def audio_to_text(audio_path, output_txt_path, model_name='base'):
    model = whisper.load_model(model_name)
    result = model.transcribe(audio_path)
    with open(output_txt_path, "w", encoding="utf-8") as f:
        f.write(result['text'])
    return result['text']

def pdf_to_text(pdf_path, output_txt_path):
    doc = fitz.open(pdf_path)
    text = "".join(page.get_text() for page in doc)
    doc.close()
    with open(output_txt_path, "w", encoding="utf-8") as f:
        f.write(text)
    return text

def get_latest_file(directory):
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
    if not files:
        return None
    full_paths = [os.path.join(directory, f) for f in files]
    return max(full_paths, key=os.path.getmtime)

def delete_old_media_files(directory, keep_file):
    media_extensions = ('.pdf', '.mp4', '.mov', '.avi', '.wav', '.m4a', '.mp3')
    for f in os.listdir(directory):
        full_path = os.path.join(directory, f)
        if os.path.isfile(full_path) and full_path != keep_file and f.lower().endswith(media_extensions):
            try:
                os.remove(full_path)
                print(f"Deleted old file: {f}")
            except Exception as e:
                print(f"Failed to delete file {f}: {e}")

# Send title and description directly to the API

def send_test_details(test_id, title, description, cookies):
    url = f"http://testify-backend-incluster.testify-backend.svc.cluster.local:8000/tests/fill-test-details/{test_id}"
    payload = {
        "title": title,
        "description": description
    }
    headers = {
        "Content-Type": "application/json"
    }

    print("Sending title and description:")
    print(payload)

    try:
        response = requests.post(url, headers=headers, json=payload, cookies=cookies, timeout=10)
        print("Status:", response.status_code)
        print("Response:", response.text)

        try:
            data = response.json()
        except ValueError:
            print("Warning: Response is not valid JSON")
            data = None

        if response.ok:
            print(f"Success! test_id={test_id}")
            return data
        else:
            print(f"Failed with status code {response.status_code}")
            return None

    except Timeout:
        print("Error: Request timed out.")
        return None

    except RequestException as e:
        print(f"Request failed: {e}")
        return None

# Send text to processing API
def send_text_to_api(text, test_id, window=5, model="meta-llama/llama-3.2-3b-instruct:free"):
    url = "http://text-segmenter-service.testify-core.svc.cluster.local:8000/process"
    payload = {
        "text": text,
        "test_id": test_id,
        "window": window,
        "model": model
    }
    headers = {
        "Content-Type": "application/json"
    }

    print("Sending text to API:")
    print(payload)

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        print("Status:", response.status_code)
        print("Response:", response.text)

        # Try to parse JSON response if expected
        try:
            data = response.json()
        except ValueError:
            print("Warning: Response is not valid JSON")
            data = None

        if response.ok:
            print(f"Success! test_id={test_id}")
            return data
        else:
            print(f"Failed with status code {response.status_code}")
            return None

    except Timeout:
        print("Error: Request timed out.")
        return None

    except RequestException as e:
        print(f"Request failed: {e}")
        return None

# Entry Point
if __name__ == "__main__":
    latest_file = get_latest_file(BASE_DIR)

    if latest_file:
        delete_old_media_files(BASE_DIR, latest_file)

        ext = os.path.splitext(latest_file)[1].lower()
        output_txt_path = os.path.join(OUTPUT_DIR, "text_final.txt")

        if ext in ['.mp4', '.mov', '.avi']:
            print(f"Processing video: {os.path.basename(latest_file)}")
            start_time = time.time()
            video_to_text(latest_file, output_txt_path)
            title = "Video Transcript"
            description = f"Transcript generated from video file {os.path.basename(latest_file)}"
        elif ext in ['.wav', '.m4a', '.mp3']:
            print(f"Processing audio: {os.path.basename(latest_file)}")
            start_time = time.time()
            audio_to_text(latest_file, output_txt_path)
            title = "Audio Transcript"
            description = f"Transcript generated from audio file {os.path.basename(latest_file)}"
        elif ext == '.pdf':
            print(f"Processing PDF: {os.path.basename(latest_file)}")
            start_time = time.time()
            pdf_to_text(latest_file, output_txt_path)
            title = "PDF Text"
            description = f"Extracted text from PDF file {os.path.basename(latest_file)}"
        else:
            print(f"Unsupported file type: {os.path.basename(latest_file)}")
            exit(1)

        # Clean output text
        with open(output_txt_path, 'r', encoding='utf-8') as infile:
            lines = infile.readlines()
        non_empty_lines = [line for line in lines if line.strip()]
        with open(output_txt_path, 'w', encoding='utf-8') as outfile:
            outfile.writelines(non_empty_lines)

        # Read final cleaned text
        with open(output_txt_path, "r", encoding="utf-8") as f:
            extracted_text = f.read()

        print("Waiting 5 seconds before sending request...")
        time.sleep(5)

        # Generate test_id and send requests
        test_id = generate_unique_id()
        send_text_to_api(extracted_text, test_id)
        send_test_details(test_id, title, description)

        end_time = time.time()
        print(f"Done! Execution time: {end_time - start_time:.2f} seconds")
    else:
        print("No files available for processing.")
