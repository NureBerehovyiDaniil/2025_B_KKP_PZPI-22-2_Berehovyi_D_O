import os
import sys
import uuid
import shutil
from fastapi import FastAPI, File, UploadFile, HTTPException, Request, APIRouter
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import requests
from requests.exceptions import RequestException

# Import media processor
try:
    sys.path.append(os.path.abspath(os.path.dirname(__file__)))
    import back_transform
except ImportError:
    print("Missing 'back_transform.py'")

app = FastAPI()

# Set up router for APIs
api_router = APIRouter()

# CORS settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:61622", "http://localhost:30002"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "front-media", "server", "uploads", "output")
FRONTEND_DIST_PATH = os.path.join(BASE_DIR, "front-media", "dist")
app.mount("/app", StaticFiles(directory=FRONTEND_DIST_PATH, html=True), name="frontend")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

@api_router.get("/ping")
async def ping():
    return {"message": "pong"}


UPLOAD_DIR = "/path/to/uploads"
OUTPUT_DIR = "/path/to/outputs"

@api_router.post("/upload")
async def upload_file(request: Request, file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename)[1].lower()
    unique_name = f"{uuid.uuid4()}{ext}"
    test_id = unique_name.replace(ext, "")  # 👉 test_id формируется сразу
    input_path = os.path.join(UPLOAD_DIR, unique_name)
    output_txt_path = os.path.join(OUTPUT_DIR, "text_final.txt")

    with open(input_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    text_content = ""
    title = "Generated Text"
    description = f"Content from file: {file.filename}"

    if ext in ['.mp4', '.mov', '.avi']:
        text_content = back_transform.video_to_text(input_path, output_txt_path)
        title = "Video Transcript"
    elif ext in ['.wav', '.m4a', '.mp3']:
        text_content = back_transform.audio_to_text(input_path, output_txt_path)
        title = "Audio Transcript"
    elif ext == '.pdf':
        text_content = back_transform.pdf_to_text(input_path, output_txt_path)
        title = "PDF Text"
    else:
        os.remove(input_path)
        raise HTTPException(status_code=400, detail="Unsupported file type.")

    os.remove(input_path)
    back_transform.send_text_to_api(text_content, test_id)
    
    cookies = request.cookies
    back_transform.send_test_details(test_id, title, description, cookies)

    return {
        "message": "File processed successfully!",
        "text": text_content,
        "filename": "text_final.txt"
    }


@api_router.get("/files")
async def list_files():
    return JSONResponse(content=[
        f for f in os.listdir(OUTPUT_DIR) if f.endswith(".txt")
    ])


@api_router.get("/files/{filename}")
async def read_file(filename: str):
    file_path = os.path.join(OUTPUT_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Text file not found.")

    with open(file_path, "r", encoding="utf-8") as f:
        return {
            "title": "",
            "description": "",
            "content": f.read()
        }


@api_router.post("/files/{filename}")
async def save_file(filename: str, request: Request):
    file_path = os.path.join(OUTPUT_DIR, filename)
    test_id = filename.replace(".txt", "")
    data = await request.json()
    title = data.get("title", "")
    description = data.get("description", "")
    content = data.get("content", "")

    if not content:
        raise HTTPException(status_code=400, detail="Missing content.")

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)

    payload = {
        "title": title,
        "description": description
    }
    requests.post(f"http://testify-backend-incluster.testify-backend.svc.cluster.local:8000/tests/fill-test-details/{test_id}", json=payload, cookies=request.cookies)

    return {"message": "File and metadata sent successfully"}


@api_router.post("/save_json/{json_filename}")
async def save_json_file_as_txt(json_filename: str, request: Request):
    file_path = os.path.join(OUTPUT_DIR, "text_final.txt")
    data = await request.json()
    title = data.get("title", "")
    description = data.get("description", "")
    content = data.get("content", "")

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(f"Title: {title}\nDescription: {description}\n\n{content}")

    return {"message": f"File 'text_final.txt' saved successfully."}


# Mount router under /api
app.include_router(api_router, prefix="/api")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=4000, reload=True)
