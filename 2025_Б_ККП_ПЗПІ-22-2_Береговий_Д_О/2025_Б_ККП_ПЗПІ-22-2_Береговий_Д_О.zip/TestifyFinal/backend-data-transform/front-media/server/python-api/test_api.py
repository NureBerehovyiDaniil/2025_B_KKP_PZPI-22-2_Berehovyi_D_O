import requests
import json

url = "http://localhost:4000/save_json/test_filename.json" # The filename here doesn't matter for backend logic
headers = {"Content-Type": "application/json"}
payload = {
    "title": "My Test Title",
    "description": "This is a test description.",
    "content": "Hello from the test script!"
}

try:
    response = requests.post(url, headers=headers, data=json.dumps(payload))
    response.raise_for_status() # Raise an exception for HTTP errors (4xx or 5xx)

    print("Success!")
    print("Status Code:", response.status_code)
    print("Response JSON:", response.json())
except requests.exceptions.HTTPError as http_err:
    print(f"HTTP error occurred: {http_err}")
    print("Status Code:", response.status_code)
    print("Response Text:", response.text)
except Exception as err:
    print(f"Other error occurred: {err}")