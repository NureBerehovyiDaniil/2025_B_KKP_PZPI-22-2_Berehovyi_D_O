# 🎥📔 Video & PDF to Text Converter

This Python script extracts text from:

* 🎮 **Video files** (transcribes audio using OpenAI Whisper)
* 📚 **PDF documents** (extracts page text using PyMuPDF)

It supports multilingual input and saves the results into clean `.txt` files for easy use or further processing.

---

## 🚀 Features

* ✅ Converts **.mp4 videos** to transcribed text using Whisper
* ✅ Extracts full text from **PDF files**
* ✅ Cleans up empty lines in output
* ✅ Saves results into:

  * `video_text.txt`, `video_text_final.txt`
  * `pdf_text.txt`, `pdf_text_final.txt`
* ✅ Displays execution time

---

## 📦 Installation

1. **Clone the repository** or download the script.
2. **Install required packages**:

```bash
pip install -r requirements.txt
```

3. **Install FFmpeg** (needed for video/audio processing):

* [Download FFmpeg](https://ffmpeg.org/download.html)
* Add `ffmpeg` to your system PATH.

---

## 💻 Usage

1. **Place your files** in the project folder:

   * A video file named: `videoplayback.mp4`
   * Or a PDF file named: `example_document.pdf`

2. **Run the script**:

```bash
python back_transform.py
```

3. **Results**:

   * Extracted text will be saved as `.txt` files.
   * Empty lines are removed in the `_final.txt` versions.

---

## 📁 Output Files

* `video_text.txt` — raw transcription from video
* `video_text_final.txt` — cleaned version
* `pdf_text.txt` — raw text from PDF
* `pdf_text_final.txt` — cleaned version

---

## 🧠 Requirements (partial)

Key packages:

* `openai-whisper`
* `moviepy`
* `PyMuPDF`
* `torch`
* `ffmpeg` (external binary)
* `imageio-ffmpeg`

Install all using:

```bash
pip install -r requirements.txt
```

---

## 🔧 Customization

* Change the default filenames inside `back_transform.py`.
* You can use other Whisper models: `'small'`, `'medium'`, `'large'`.

---

## 👤 Author

Email: `daniil.berehovyi@nure.ua` 

Link to samples (https://drive.google.com/drive/folders/14jCaiCpy36ayPxGWSvqC8DO7aloFVEaa?usp=sharing)
