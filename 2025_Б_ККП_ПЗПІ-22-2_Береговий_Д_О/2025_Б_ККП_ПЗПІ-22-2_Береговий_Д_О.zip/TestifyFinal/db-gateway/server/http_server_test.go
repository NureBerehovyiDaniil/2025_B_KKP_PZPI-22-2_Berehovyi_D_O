package server

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"

	"github.com/go-redis/redismock/v9"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
)

var _ = Describe("HTTP Server", func() {
	var (
		mockRedisClient redismock.ClientMock
		serverInstance  *httpServer // Correctly instantiate the httpServer struct
	)

	BeforeEach(func() {
		// Initialize a mock Redis client
		client, mock := redismock.NewClientMock()
		mockRedisClient = mock
		serverInstance = &httpServer{redisClient: client} // Proper instantiation
	})

	Context("SubmitQuestion", func() {
		It("should return 400 for invalid request body", func() {
			req := httptest.NewRequest(http.MethodPost, "/submit-question", bytes.NewBuffer([]byte("invalid")))
			req.Header.Set("Content-Type", "application/json")
			rec := httptest.NewRecorder()

			serverInstance.handleSubmitQuestion(rec, req) // Use the properly instantiated serverInstance

			Expect(rec.Code).To(Equal(http.StatusBadRequest))
			Expect(rec.Body.String()).To(ContainSubstring("invalid request body"))
		})
	})

	Context("TestExists", func() {
		It("should return true if the test exists", func() {
			mockRedisClient.ExpectExists("test:test1:questions").SetVal(1)

			req := httptest.NewRequest(http.MethodGet, "/test/exists?test_id=test1", nil)
			rec := httptest.NewRecorder()

			serverInstance.handleTestExists(rec, req) // Use the properly instantiated serverInstance

			Expect(rec.Code).To(Equal(http.StatusOK))

			var resp map[string]bool
			Expect(json.NewDecoder(rec.Body).Decode(&resp)).To(Succeed())
			Expect(resp["exists"]).To(BeTrue())
		})

		It("should return false if the test does not exist", func() {
			mockRedisClient.ExpectExists("test:test1:questions").SetVal(0)

			req := httptest.NewRequest(http.MethodGet, "/test/exists?test_id=test1", nil)
			rec := httptest.NewRecorder()

			serverInstance.handleTestExists(rec, req) // Use the properly instantiated serverInstance

			Expect(rec.Code).To(Equal(http.StatusOK))

			var resp map[string]bool
			Expect(json.NewDecoder(rec.Body).Decode(&resp)).To(Succeed())
			Expect(resp["exists"]).To(BeFalse())
		})
	})
})
