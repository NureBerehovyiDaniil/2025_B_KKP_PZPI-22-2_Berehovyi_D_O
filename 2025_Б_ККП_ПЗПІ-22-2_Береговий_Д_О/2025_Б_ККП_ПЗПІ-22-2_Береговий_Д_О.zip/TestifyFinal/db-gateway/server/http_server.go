package server

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"

	pb "db-gateway/db-gateway/proto/question"
	"github.com/redis/go-redis/v9"
)

type Option = pb.Option

type Question struct {
	Question string       `json:"question"`
	Options  []*pb.Option `json:"options"`
	Tags     []string     `json:"tags"`
	TestID   string       `json:"test_id"`
}

type SubmitQuestionRequest struct {
	TestId       string       `json:"test_id"`
	QuestionText string       `json:"question"`
	Options      []*pb.Option `json:"options"`
	Tags         []string     `json:"tags"`
}

type SubmitQuestionResponse struct {
	Status     string `json:"status"`
	QuestionId string `json:"question_id"`
}

type httpServer struct {
	redisClient *redis.Client
}

var httpCtx = context.Background()

// Retrieves a question by test ID and question ID.
func (s *httpServer) getQuestion(testId, qid string) (*Question, error) {
	key := "test:" + testId + ":question:" + qid
	val, err := s.redisClient.Get(httpCtx, key).Result()
	if err != nil {
		return nil, err
	}
	var rq Question
	if err := json.Unmarshal([]byte(val), &rq); err != nil {
		return nil, err
	}
	for i, opt := range rq.Options {
		if opt.Id == "" {
			opt.Id = fmt.Sprintf("%d", i+1)
		}
	}
	return &rq, nil
}

// IsTestExists Checks if a test exists by its test ID.
func (s *httpServer) IsTestExists(testId string) bool {
	exists, err := s.redisClient.Exists(httpCtx, "test:"+testId+":questions").Result()
	return err == nil && exists > 0
}

// GetQuestionsByTestId Retrieves all question IDs and tags for a given test ID.
func (s *httpServer) GetQuestionsByTestId(testId string) (questionIds []string, tags []string) {
	ids, err := s.redisClient.SMembers(httpCtx, "test:"+testId+":questions").Result()
	if err != nil {
		return nil, nil
	}
	tagKeys, err := s.redisClient.Keys(httpCtx, "test:"+testId+":tags:*").Result()
	if err != nil {
		return ids, nil
	}
	tagSet := make(map[string]struct{})
	for _, key := range tagKeys {
		parts := strings.Split(key, ":")
		if len(parts) == 4 {
			tagSet[parts[3]] = struct{}{}
		}
	}
	for tag := range tagSet {
		tags = append(tags, tag)
	}
	return ids, tags
}

// GetQuestionById Retrieves all options for a given test ID and question ID.
func (s *httpServer) GetQuestionById(testId, questionId string) (options []*pb.Option) {
	q, err := s.getQuestion(testId, questionId)
	if err != nil {
		return nil
	}
	return q.Options
}

// GetQuestionOptionByID Retrieves the option and its correctness for a given test ID, question ID, and option ID.
func (s *httpServer) GetQuestionOptionByID(testId, questionId, optionId string) (option *pb.Option, isCorrect bool) {
	q, err := s.getQuestion(testId, questionId)
	if err != nil {
		return nil, false
	}
	for _, opt := range q.Options {
		if opt.Id == optionId {
			return opt, opt.Correct
		}
	}
	return nil, false
}

// GetQuestionCorrectAnswer Retrieves the correct answer's option ID for a given test ID and question ID.
func (s *httpServer) GetQuestionCorrectAnswer(testId, questionId string) (optionId string) {
	q, err := s.getQuestion(testId, questionId)
	if err != nil {
		return ""
	}
	for _, opt := range q.Options {
		if opt.Correct {
			return opt.Id
		}
	}
	return ""
}

// GetAllQuestions Handles the retrieval of all questions across all tests.
func (s *httpServer) GetAllQuestions(w http.ResponseWriter, r *http.Request) {
	keys, err := s.redisClient.Keys(httpCtx, "test:*:question:*").Result()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	var questions []Question
	for _, key := range keys {
		parts := strings.Split(key, ":")
		if len(parts) != 4 {
			continue
		}
		testID, qid := parts[1], parts[3]
		if q, err := s.getQuestion(testID, qid); err == nil {
			questions = append(questions, *q)
		}
	}
	json.NewEncoder(w).Encode(questions)
}

// GetAllQuestionsByTestId Handles the retrieval of all questions for a specific test ID.
func (s *httpServer) GetAllQuestionsByTestId(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	if testID == "" {
		http.Error(w, "test_id required", 400)
		return
	}
	ids, err := s.redisClient.SMembers(httpCtx, "test:"+testID+":questions").Result()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	var questions []Question
	for _, id := range ids {
		if q, err := s.getQuestion(testID, id); err == nil {
			questions = append(questions, *q)
		}
	}
	err = json.NewEncoder(w).Encode(questions)
	if err != nil {
		_ = fmt.Errorf("failed to encode response: %v", err)
	}
}

// GetQuestionsByTagsInTest Handles the retrieval of questions by tags within a specific test.
func (s *httpServer) GetQuestionsByTagsInTest(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	tags := r.URL.Query()["tag"]
	if testID == "" || len(tags) == 0 {
		http.Error(w, "test_id and at least one tag required", 400)
		return
	}
	var keys []string
	for _, tag := range tags {
		keys = append(keys, "test:"+testID+":tags:"+tag)
	}
	ids, err := s.redisClient.SInter(httpCtx, keys...).Result()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	var questions []Question
	for _, id := range ids {
		if q, err := s.getQuestion(testID, id); err == nil {
			questions = append(questions, *q)
		}
	}
	json.NewEncoder(w).Encode(questions)
}

// GetQuestionsByTags Handles the retrieval of questions by tags across all tests.
func (s *httpServer) GetQuestionsByTags(w http.ResponseWriter, r *http.Request) {
	tags := r.URL.Query()["tag"]
	if len(tags) == 0 {
		http.Error(w, "at least one tag required", 400)
		return
	}
	tagKeys, err := s.redisClient.Keys(httpCtx, "test:*:tags:*").Result()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	questionsMap := make(map[string]Question)
	for _, tag := range tags {
		for _, key := range tagKeys {
			if strings.HasSuffix(key, ":"+tag) {
				parts := strings.Split(key, ":")
				if len(parts) != 4 {
					continue
				}
				testID := parts[1]
				ids, err := s.redisClient.SMembers(httpCtx, key).Result()
				if err != nil {
					continue
				}
				for _, id := range ids {
					if q, err := s.getQuestion(testID, id); err == nil {
						questionsMap[testID+":"+id] = *q
					}
				}
			}
		}
	}
	var questions []Question
	for _, q := range questionsMap {
		questions = append(questions, q)
	}
	err = json.NewEncoder(w).Encode(questions)
	if err != nil {
		_ = fmt.Errorf("failed to encode response: %v", err)
	}
}

// GetQuestionsIDsByTagsInTest Handles the retrieval of question IDs by tags within a specific test.
func (s *httpServer) GetQuestionsIDsByTagsInTest(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	tags := r.URL.Query()["tag"]
	if testID == "" || len(tags) == 0 {
		http.Error(w, "test_id and at least one tag required", 400)
		return
	}
	var keys []string
	for _, tag := range tags {
		keys = append(keys, "test:"+testID+":tags:"+tag)
	}
	ids, err := s.redisClient.SInter(httpCtx, keys...).Result()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	err = json.NewEncoder(w).Encode(map[string][]string{"question_ids": ids})
	if err != nil {
		_ = fmt.Errorf("failed to encode response: %v", err)
	}
}

// Handles the check for test existence by test ID.
func (s *httpServer) handleTestExists(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	if testID == "" {
		http.Error(w, "test_id required", 400)
		return
	}
	exists := s.IsTestExists(testID)
	json.NewEncoder(w).Encode(map[string]bool{"exists": exists})
}

// Handles the retrieval of question IDs and tags for a specific test ID.
func (s *httpServer) handleTestQuestions(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	if testID == "" {
		http.Error(w, "test_id required", 400)
		return
	}
	ids, tags := s.GetQuestionsByTestId(testID)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"question_ids": ids,
		"tags":         tags,
	})
}

// Handles the retrieval of options for a specific question.
func (s *httpServer) handleQuestionOptions(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	questionID := r.URL.Query().Get("question_id")
	if testID == "" || questionID == "" {
		http.Error(w, "test_id and question_id required", 400)
		return
	}
	options := s.GetQuestionById(testID, questionID)
	json.NewEncoder(w).Encode(options)
}

// Handles the retrieval of a specific option and its correctness.
func (s *httpServer) handleQuestionOptionByID(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	questionID := r.URL.Query().Get("question_id")
	optionID := r.URL.Query().Get("option_id")
	if testID == "" || questionID == "" || optionID == "" {
		http.Error(w, "test_id, question_id and option_id required", 400)
		return
	}
	option, isCorrect := s.GetQuestionOptionByID(testID, questionID, optionID)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"option":    option,
		"isCorrect": isCorrect,
	})
}

// Handles the retrieval of the correct option ID for a specific question.
func (s *httpServer) handleQuestionCorrectOption(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	questionID := r.URL.Query().Get("question_id")
	if testID == "" || questionID == "" {
		http.Error(w, "test_id and question_id required", 400)
		return
	}
	optionID := s.GetQuestionCorrectAnswer(testID, questionID)
	json.NewEncoder(w).Encode(map[string]string{
		"option_id": optionID,
	})
}

// Handles the retrieval of a question by its ID.
func (s *httpServer) handleQuestionById(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	questionID := r.URL.Query().Get("question_id")
	if testID == "" || questionID == "" {
		http.Error(w, "test_id and question_id required", 400)
		return
	}
	q, err := s.getQuestion(testID, questionID)
	if err != nil {
		http.Error(w, "question not found", 404)
		return
	}
	json.NewEncoder(w).Encode(q)
}

// Handles the submission of a new question.
func (s *httpServer) handleSubmitQuestion(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req SubmitQuestionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", 400)
		return
	}
	if req.TestId == "" || req.QuestionText == "" || len(req.Options) == 0 {
		http.Error(w, "test_id, question and options required", 400)
		return
	}
	id := fmt.Sprintf("%d", s.redisClient.Incr(httpCtx, "global:question_id").Val())
	key := fmt.Sprintf("test:%s:question:%s", req.TestId, id)

	options := make([]*pb.Option, len(req.Options))
	for i, opt := range req.Options {
		options[i] = &pb.Option{
			Id:      fmt.Sprintf("%d", i+1),
			Text:    opt.Text,
			Correct: opt.Correct,
		}
	}

	question := Question{
		Question: req.QuestionText,
		Options:  options,
		Tags:     req.Tags,
		TestID:   req.TestId,
	}

	data, err := json.Marshal(question)
	if err != nil {
		http.Error(w, "failed to marshal question", 500)
		return
	}

	if err := s.redisClient.Set(httpCtx, key, data, 0).Err(); err != nil {
		http.Error(w, "failed to save question", 500)
		return
	}

	s.redisClient.SAdd(httpCtx, fmt.Sprintf("test:%s:questions", req.TestId), id)
	for _, tag := range req.Tags {
		s.redisClient.SAdd(httpCtx, fmt.Sprintf("test:%s:tags:%s", req.TestId, tag), id)
	}

	resp := SubmitQuestionResponse{Status: "ok", QuestionId: id}
	json.NewEncoder(w).Encode(resp)
}

// GetAllQuestionsIdsByTestId Handles the retrieval of all question IDs for a specific test ID.
func (s *httpServer) GetAllQuestionsIdsByTestId(w http.ResponseWriter, r *http.Request) {
	testID := r.URL.Query().Get("test_id")
	if testID == "" {
		http.Error(w, "test_id required", 400)
		return
	}
	ids, err := s.redisClient.SMembers(httpCtx, "test:"+testID+":questions").Result()
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	err = json.NewEncoder(w).Encode(map[string][]string{"question_ids": ids})
	if err != nil {
		_ = fmt.Errorf("failed to encode response: %v", err)
	}
}

// StartHTTPServer Starts the HTTP server and registers all endpoints.
func StartHTTPServer(rdb *redis.Client) {
	s := &httpServer{redisClient: rdb}

	http.HandleFunc("/submit-question", s.handleSubmitQuestion)
	http.HandleFunc("/questions", s.GetAllQuestions)
	http.HandleFunc("/questions/by-test", s.GetAllQuestionsByTestId)
	http.HandleFunc("/questions/ids-by-test", s.GetAllQuestionsIdsByTestId)
	http.HandleFunc("/questions/by-tags-in-test", s.GetQuestionsByTagsInTest)
	http.HandleFunc("/questions/ids-by-tags-in-test", s.GetQuestionsIDsByTagsInTest)
	http.HandleFunc("/questions/by-tags", s.GetQuestionsByTags)
	http.HandleFunc("/question/by-id", s.handleQuestionById)
	http.HandleFunc("/test/exists", s.handleTestExists)
	http.HandleFunc("/test/questions", s.handleTestQuestions)
	http.HandleFunc("/question/options", s.handleQuestionOptions)
	http.HandleFunc("/question/option", s.handleQuestionOptionByID)
	http.HandleFunc("/question/correct-option", s.handleQuestionCorrectOption)

	log.Println("HTTP server listening on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
