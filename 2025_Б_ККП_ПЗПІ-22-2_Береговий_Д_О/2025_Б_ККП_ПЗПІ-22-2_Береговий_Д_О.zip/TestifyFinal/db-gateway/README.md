# db-gateway
dbgateway is a high-performance, language-agnostic gRPC microservice written in Go that acts as a centralized gateway for storing structured Question objects in Redis. Designed to serve multiple Python-based containers concurrently, it provides a simple yet robust API

## Usage Instructions

### 1. Start the Service

Use docker compose to start the service. The service will run on `localhost:50051`.

```bash
docker-compose up
```

Ensure the service is running and accessible on `localhost:50051`. The service uses gRPC for communication.
To check if the service is running, you can use the following command:

```bash
grpcurl -plaintext localhost:50051 list
```

### 2. gRPC Methods

#### **Submit a New Question**
To create a new question, use the `SubmitQuestion` RPC method.

- **Request:**
  ```json
  {
    "test_id": "test123",
    "question_text": "What is the capital of France?",
    "options": [
      {"text": "Paris", "correct": true},
      {"text": "London", "correct": false},
      {"text": "Berlin", "correct": false}
    ],
    "tags": ["geography", "europe"]
  }
  ```

- **Response:**
  ```json
  {
    "status": "ok",
    "question_id": "1"
  }
  ```

#### **Get All Questions by Test ID**
To retrieve all questions for a specific test, use the `GetAllQuestionsByTestId` RPC method.

- **Request:**
  ```json
  {
    "test_id": "test123"
  }
  ```

- **Response:**
  ```json
  {
    "questions": [
      {
        "question_id": "1",
        "question_text": "What is the capital of France?",
        "options": [
          {"text": "Paris", "correct": true},
          {"text": "London", "correct": false},
          {"text": "Berlin", "correct": false}
        ],
        "tags": ["geography", "europe"],
        "test_id": "test123"
      }
    ]
  }
  ```

#### **Get All Questions by Test ID and Tags**
To filter questions by test ID and tags, use the `GetAllQuestionsByTestIdAndTags` RPC method.

- **Request:**
  ```json
  {
    "test_id": "test123",
    "tags": ["geography"]
  }
  ```

- **Response:**
  ```json
  {
    "questions": [
      {
        "question_id": "1",
        "question_text": "What is the capital of France?",
        "options": [
          {"text": "Paris", "correct": true},
          {"text": "London", "correct": false},
          {"text": "Berlin", "correct": false}
        ],
        "tags": ["geography", "europe"],
        "test_id": "test123"
      }
    ]
  }
  ```

#### **Get All Questions**
To retrieve all questions across all tests, use the `GetAllQuestions` RPC method.

- **Request:**
  ```json
  {}
  ```

- **Response:**
  ```json
  {
    "questions": [
      {
        "question_id": "1",
        "question_text": "What is the capital of France?",
        "options": [
          {"text": "Paris", "correct": true},
          {"text": "London", "correct": false},
          {"text": "Berlin", "correct": false}
        ],
        "tags": ["geography", "europe"],
        "test_id": "test123"
      }
    ]
  }
  ```

#### **Check if a Test ID Exists**
To check if a test ID exists, use the `TestIdExists` RPC method.

- **Request:**
  ```json
  {
    "test_id": "test123"
  }
  ```

- **Response:**
  ```json
  {
    "exists": true
  }
  ```

### Http API

The service also provides a simple HTTP API for easy access.

#### **Get All Questions**

- **Endpoint:** `GET /questions`
- **Description:** Returns all questions across all tests.
- **Example Request:**
  ```
  curl http://localhost:8080/questions
  ```
- **Response:**
  ```json
  [
    {
      "question": "What is the capital of France?",
      "options": [
        {"text": "Paris", "correct": true},
        {"text": "London", "correct": false},
        {"text": "Berlin", "correct": false}
      ],
      "tags": ["geography", "europe"],
      "test_id": "test123"
    }
  ]
  ```

#### **Get All Questions By Test ID**

- **Endpoint:** `GET /questions/by-test?test_id={test_id}`
- **Description:** Returns all questions for a specific test.
- **Example Request:**
  ```
  curl "http://localhost:8080/questions/by-test?test_id=test123"
  ```
- **Response:** Same as above, filtered by test_id.

#### **Get Questions By Tags In Test**

- **Endpoint:** `GET /questions/by-tags-in-test?test_id={test_id}&tag=tag1&tag=tag2`
- **Description:** Returns questions in a test that have all specified tags.
- **Example Request:**
  ```
  curl "http://localhost:8080/questions/by-tags-in-test?test_id=test123&tag=geography"
  ```
- **Response:** Same as above, filtered by tags and test_id.

#### **Get Questions By Tags (across all tests)**

- **Endpoint:** `GET /questions/by-tags?tag=tag1&tag=tag2`
- **Description:** Returns questions across all tests that have the specified tags.
- **Example Request:**
  ```
  curl "http://localhost:8080/questions/by-tags?tag=geography"
  ```
- **Response:** Same as above, filtered by tags.

**Note:** All HTTP endpoints return a JSON array of question objects.

