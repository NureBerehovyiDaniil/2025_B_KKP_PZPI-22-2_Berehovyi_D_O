import json
import re

import openai
from openai.types.chat import ChatCompletionUserMessageParam, ChatCompletionSystemMessageParam

from processor.question import Question


def fields_correct(question):
    """
    Validate the fields of the question object.
    :param question: Question object to validate.
    :return: True if the question is valid, False otherwise.
    """
    if not isinstance(question, Question):
        return False

    if not question.question_text or not isinstance(question.question_text, str):
        return False

    if not question.options or not isinstance(question.options, list):
        return False

    correct_count = 0
    for option in question.options:
        if not isinstance(option, dict) or 'text' not in option or 'correct' not in option:
            return False
        if not isinstance(option['text'], str) or not isinstance(option['correct'], bool):
            return False
        if option['correct']:
            correct_count += 1

    return correct_count == 1


class Validator:
    """
    Validator is a tool for semantic and structural validation of generated questions.
    """

    def __init__(self, api_key: str, prompt: str, model: str, base_url: str):
        self.validation_prompt = prompt
        self.model = model
        self.client = openai.OpenAI(api_key=api_key, base_url=base_url)

    def validate(self, question: Question) -> tuple[bool, str]:
        """
        Validates a question using the LLM.

        Returns:
            (bool, str): Tuple of is_valid (True/False) and explanation (if any).
        """
        if not fields_correct(question):
            return False, "Question structure is invalid: missing text or malformed options."

        user_prompt = f"Question:\n\n{json.dumps(question.to_dict(), ensure_ascii=False, indent=2)}"

        messages = [
            ChatCompletionSystemMessageParam(role="system", content=self.validation_prompt),
            ChatCompletionUserMessageParam(role="user", content=user_prompt)
        ]

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages
            )
            content = response.choices[0].message.content.strip()

            # Extract only valid JSON
            match = re.search(r"\{.*\}", content, re.DOTALL)
            if not match:
                return False, f"Validation failed. Invalid response format:\n{content}"

            result = json.loads(match.group(0))

            is_valid = result.get("valid", False)

            return is_valid, ""
        except Exception as e:
            return False, f"Validation failed with exception: {e}"
