import os
import sys

from processor.processor import Processor
from processor.question_context import QuestionContext
from prompts import SYSTEM_PROMPT
from validator.validator import Validator
from manager.manager import Manager

validation_enabled = True
model = os.getenv("MODEL", "meta-llama/llama-3.2-3b-instruct:free")
base_url = "https://openrouter.ai/api/v1"
key_store_url = os.getenv("KEY_STORE_URL", "")
question_store_url = os.getenv("QUESTION_STORE_URL", "")
input_text = os.getenv("INPUT_TEXT", "")
test_id = os.getenv("TEST_ID", "0")

if __name__ == "__main__":

    if not input_text:
        print("No input text provided. Please set the INPUT_TEXT environment variable.")
        sys.exit(1)

    if not test_id:
        print("No test ID provided. Please set the TEST_ID environment variable.")
        sys.exit(1)

    if not question_store_url:
        print("No question store URL provided. Please set the QUESTION_STORE_URL environment variable.")
        sys.exit(1)

    # Retrieve the API key from the key store service.
    if not key_store_url:
        print("No key store URL provided. Please set the KEY_STORE_URL environment variable.")
        sys.exit(1)
    try:
        key = Manager.get_key(key_store_url)
        if not key:
            print("Failed to retrieve API key from key store.")
            sys.exit(1)
    except Exception as e:
        print(f"Error retrieving API key: {e}")
        sys.exit(1)

    processor = Processor(key, SYSTEM_PROMPT, model, base_url)
    validator = Validator(key, SYSTEM_PROMPT, model, base_url)
    text_obj = QuestionContext(input_text=input_text)

    try:
        print(f"Running test with ID: {test_id}")
        question = processor.generate_question(text_obj)
        print(question)

        if validation_enabled:
            print("Validating question...")
            is_valid = validator.validate(question)
            if is_valid:
                options = []
                for opt in question.options:
                    options.append({
                        "id": "0",
                        "text": opt.get("text", ""),
                        "correct": opt.get("correct", False)
                    })

                question_payload = {
                    "test_id": test_id,
                    "question_text": question.question_text,
                    "options": options,
                    "tags": getattr(question, "tags", [])
                }
                Manager.send_question(question_store_url, question_payload)
            else:
                print("❌ Question is invalid.")
                sys.exit(1)
    except Exception as e:
        print("Error:", e)
        sys.exit(1)
