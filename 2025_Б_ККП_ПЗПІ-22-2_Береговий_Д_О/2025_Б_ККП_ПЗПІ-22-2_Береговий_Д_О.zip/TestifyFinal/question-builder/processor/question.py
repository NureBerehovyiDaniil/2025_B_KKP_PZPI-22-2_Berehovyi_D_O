from typing import List, Dict


class Question:
    """
    This module defines a Question class that represents a question with its text, possible answers, and tags.
    """

    def __init__(self, question_text: str, options: List[Dict], tags: List[str] = None):
        """
        Initialize a new instance of the Question class.

        Args:
            question_text (str): The text of the question.
            options (List[Dict]): A list of dictionaries where each dictionary represents an option.
            tags (List[str], optional): A list of tags associated with the question. Defaults to an empty list if not provided.
        """
        self.question_text = question_text
        self.options = options
        self.tags = tags or []

    def __str__(self):
        """
        Generate a formatted string representation of the question.

        Returns:
            str: A formatted string that includes the question text, a numbered list of options with correctness status, and associated tags.
        """
        options_str = "\n".join(
            f"  {idx}. {option.get('text', '')} ({'correct' if option.get('correct', False) else 'incorrect'})"
            for idx, option in enumerate(self.options, 1)
        )
        tags_str = ", ".join(self.tags)
        return f"Question: {self.question_text}\nOptions:\n{options_str}\nTags: {tags_str}"

    def to_dict(self) -> Dict:
        """
        Serialize the Question to a dictionary.

        Returns:
            dict: A dictionary representation of the question, suitable for JSON.
        """
        return {
            "question": self.question_text,
            "options": self.options,
            "tags": self.tags
        }
