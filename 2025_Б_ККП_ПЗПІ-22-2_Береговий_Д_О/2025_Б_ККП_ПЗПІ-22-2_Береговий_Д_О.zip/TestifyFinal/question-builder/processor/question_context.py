class QuestionContext:
    """
    Represents the input text and its associated formatting prompt for question generation.
    """

    def __init__(self, input_text: str, mode: str = "default"):
        """
        Initialize with the input text and optional mode (e.g., difficulty level).
        """
        self.input_text = input_text
        self.mode = mode

    def formatted_prompt(self) -> str:
        """
        Insert the input text into the predefined prompt format.
        """
        return f'Text to process: "{self.input_text}"'
