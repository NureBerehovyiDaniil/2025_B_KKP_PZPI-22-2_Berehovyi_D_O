import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Home from './pages/Home'
import TestEdit from './pages/TestEdit'
import TestTaking from './pages/TestTaking'
import TestResults from './pages/TestResults'
import UserTakes from './pages/UserTakes'
import UserTakeDetails from './pages/UserTakeDetails'
import UserTests from './pages/UserTests'
import UploadNewTest from './pages/UploadNewTest'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/home" element={<Home />} />
        <Route path="/tests/:testId/edit" element={<TestEdit />} />
        <Route path="/tests/:testId" element={<TestTaking />} />
        <Route path="/results" element={<TestResults />} />
        <Route path="/my-takes" element={<UserTakes />} />
        <Route path="/my-takes/:takeId" element={<UserTakeDetails />} />
        <Route path="/my-tests/" element={<UserTests />} />
        <Route path="/upload-new-test" element={<UploadNewTest />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
