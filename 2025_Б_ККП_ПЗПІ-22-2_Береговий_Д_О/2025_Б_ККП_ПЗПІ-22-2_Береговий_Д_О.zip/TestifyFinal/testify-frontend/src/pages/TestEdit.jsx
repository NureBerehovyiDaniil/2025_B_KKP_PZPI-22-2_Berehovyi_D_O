import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { testService } from '../services/testService';
import { MOCK_TEST_DETAILS } from '../mocks';
import { BookOpen, ArrowLeft, Plus, X, Check, Trash2, Edit3, Save, Hash, AlertTriangle } from 'lucide-react';

export default function TestEdit() {
  const { testId } = useParams();
  const navigate = useNavigate();
  const [test, setTest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeQuestion, setActiveQuestion] = useState(null);
  const [editMode, setEditMode] = useState('test'); // 'test' or 'question'
  const [isNewQuestion, setIsNewQuestion] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteType, setDeleteType] = useState(null); // 'test' or 'question'
  const [questionToDelete, setQuestionToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questionText, setQuestionText] = useState('');
  const [options, setOptions] = useState([]);
  const [tags, setTags] = useState([]);

  useEffect(() => {
    const fetchTestInfo = async () => {
      try {
        setLoading(true);
        const data = await testService.getTestInfoForEdit(testId);
        setTest(data);
        setTitle(data.title);
        setDescription(data.description);
        setTags(data.tags);
      } catch (err) {
        console.error('Failed to fetch test details, using mock data:', err);
        setTest(MOCK_TEST_DETAILS);
        setTitle(MOCK_TEST_DETAILS.title);
        setDescription(MOCK_TEST_DETAILS.description);
        setTags(MOCK_TEST_DETAILS.tags);
        setError(null);
      } finally {
        setLoading(false);
      }
    };

    fetchTestInfo();
  }, [testId]);

  const handleTestUpdate = async (e) => {
    e.preventDefault();
    try {
      await testService.editTest(testId, {
        title,
        description,
        tags,
      });
      const updatedTest = await testService.getTestInfoForEdit(testId);
      setTest(updatedTest);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleQuestionUpdate = async (e) => {
    e.preventDefault();
    if (!activeQuestion && !isNewQuestion) return;
    console.log(activeQuestion)
    try {
      if (isNewQuestion) {
        await testService.addTestQuestion(testId, {
          question: questionText,
          options,
          tags,
        });
      } else {
        await testService.editTestQuestion(testId, activeQuestion.id, {
          question: questionText,
          options,
          tags
        });
      }
      const updatedTest = await testService.getTestInfoForEdit(testId);
      setTest(updatedTest);
      setEditMode('test');
      setActiveQuestion(null);
      setIsNewQuestion(false);
      // Reset form
      setQuestionText('');
      setOptions([]);
      setTags([]);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleQuestionSelect = (question) => {
    setActiveQuestion(question);
    setQuestionText(question.question);
    setOptions(question.options || []);
    setTags(question.tags || []);
    setEditMode('question');
  };

  const handleNewQuestion = () => {
    setIsNewQuestion(true);
    setActiveQuestion(null);
    setQuestionText('');
    setOptions([]);
    setTags([]);
    setEditMode('question');
  };

  const handleDeleteTest = () => {
    setDeleteType('test');
    setShowDeleteModal(true);
  };

  const handleDeleteQuestion = (question) => {
    setDeleteType('question');
    setQuestionToDelete(question);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    setIsDeleting(true);
    try {
      if (deleteType === 'test') {
        await testService.deleteTest(testId);
        navigate('/home');
      } else if (deleteType === 'question' && questionToDelete) {
        await testService.deleteTestQuestion(testId, questionToDelete.id);
        const updatedTest = await testService.getTestInfoForEdit(testId);
        setTest(updatedTest);
        
        // If we were editing this question, go back to test mode
        if (activeQuestion?.id === questionToDelete.id) {
          setEditMode('test');
          setActiveQuestion(null);
          setQuestionText('');
          setOptions([]);
          setTags([]);
        }
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsDeleting(false);
      setShowDeleteModal(false);
      setDeleteType(null);
      setQuestionToDelete(null);
    }
  };

  const cancelDelete = () => {
    setShowDeleteModal(false);
    setDeleteType(null);
    setQuestionToDelete(null);
  };

  if (loading) return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
      <div className="text-center">
        <div className="relative mb-6">
          <div className="w-16 h-16 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-pulse"></div>
            <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="h-4 bg-gray-200 rounded-full w-48 mx-auto animate-pulse"></div>
          <div className="h-3 bg-gray-200 rounded-full w-32 mx-auto animate-pulse"></div>
        </div>
      </div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white flex items-center justify-center">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md mx-4 border border-red-100">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <X className="w-8 h-8 text-red-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Something went wrong</h3>
          <p className="text-red-600">Error: {error}</p>
        </div>
      </div>
    </div>
  );

  if (!test) return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <BookOpen className="w-8 h-8 text-gray-400" />
        </div>
        <p className="text-gray-600">Test not found</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-gray-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {deleteType === 'test' ? 'Delete Test' : 'Delete Question'}
              </h3>
              <p className="text-gray-600 mb-6">
                {deleteType === 'test' 
                  ? 'Are you sure you want to delete this entire test? This action cannot be undone and will remove all questions and data associated with this test.'
                  : 'Are you sure you want to delete this question? This action cannot be undone.'
                }
              </p>
              <div className="flex gap-3">
                <button
                  onClick={cancelDelete}
                  disabled={isDeleting}
                  className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-all duration-300 font-medium disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  disabled={isDeleting}
                  className="flex-1 px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-all duration-300 font-medium disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                  {isDeleting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4" />
                      <span>Delete</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <Edit3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Edit Test
                </h1>
                <p className="text-sm text-gray-600 mt-1">Customize your test content and questions</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={handleDeleteTest}
                className="flex items-center space-x-2 bg-red-50 text-red-600 rounded-xl px-6 py-3 hover:bg-red-100 transition-all duration-300 border border-red-200 shadow-lg hover:shadow-xl transform hover:scale-105 font-medium"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Test</span>
              </button>
              <button
                onClick={() => navigate('/home')}
                className="flex items-center space-x-2 bg-white/70 backdrop-blur-sm rounded-xl px-6 py-3 hover:bg-white/90 transition-all duration-300 border border-white/30 shadow-lg hover:shadow-xl transform hover:scale-105 text-gray-700 font-medium"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Tests</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Left Sidebar - Questions List */}
          <div className="col-span-3">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-6 sticky top-24">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-900">Questions</h2>
                <button
                  onClick={handleNewQuestion}
                  className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  <Plus className="w-4 h-4" />
                  <span>New</span>
                </button>
              </div>
              <div className="space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto">
                {test.questions.map((question, index) => (
                  <div
                    key={question.id}
                    className={`relative group p-4 rounded-xl transition-all duration-300 ${
                      activeQuestion?.id === question.id
                        ? 'bg-gradient-to-r from-indigo-50 to-purple-50 border-2 border-indigo-300 shadow-lg'
                        : 'hover:bg-white/60 border-2 border-transparent hover:border-indigo-200 bg-white/40 backdrop-blur-sm hover:shadow-md'
                    }`}
                  >
                    <button
                      onClick={() => handleQuestionSelect(question)}
                      className="w-full text-left"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Question {index + 1}</span>
                        {question.tags?.length > 0 && (
                          <span className="text-xs text-indigo-700 bg-indigo-100 px-2 py-1 rounded-full font-medium">
                            {question.tags[0]}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {question.question}
                      </p>
                    </button>
                    <button
                      onClick={() => handleDeleteQuestion(question)}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 rounded-lg border border-red-200 hover:border-red-300 transition-all duration-300 transform hover:scale-110"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="col-span-9">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8">
              {editMode === 'test' ? (
                <form onSubmit={handleTestUpdate} className="space-y-8">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-gray-900 mb-2">Test Information</h2>
                    <p className="text-gray-600">Configure your test details and settings</p>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-3">
                        Test Title
                      </label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90 text-lg"
                        placeholder="Enter an engaging test title"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-3">
                        Description
                      </label>
                      <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={5}
                        className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90 resize-none"
                        placeholder="Describe what your test covers and what participants can expect to learn"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-3">
                        Tags
                      </label>
                      <div className="flex flex-wrap gap-3 mb-4">
                        {tags.map((tag) => (
                          <span
                            key={tag}
                            className="inline-flex items-center px-4 py-2 rounded-xl text-sm font-medium bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 border border-indigo-200 shadow-sm"
                          >
                            <Hash className="w-3 h-3 mr-1" />
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center space-x-2 text-lg font-semibold"
                  >
                    <Save className="w-5 h-5" />
                    <span>Save Test Changes</span>
                  </button>
                </form>
              ) : (
                <form onSubmit={handleQuestionUpdate} className="space-y-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h2 className="text-3xl font-bold text-gray-900 mb-2">
                        {isNewQuestion ? 'Add New Question' : 'Edit Question'}
                      </h2>
                      <p className="text-gray-600">
                        {isNewQuestion ? 'Create a new question for your test' : 'Modify the selected question'}
                      </p>
                    </div>
                    <div className="flex items-center space-x-3">
                      {!isNewQuestion && activeQuestion && (
                        <button
                          type="button"
                          onClick={() => handleDeleteQuestion(activeQuestion)}
                          className="p-3 text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 rounded-xl transition-all duration-300 border border-red-200 hover:border-red-300"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setEditMode('test');
                          setActiveQuestion(null);
                          setIsNewQuestion(false);
                        }}
                        className="p-3 text-gray-500 hover:text-gray-700 bg-white/60 hover:bg-white/80 rounded-xl transition-all duration-300 border border-gray-200 hover:border-gray-300"
                      >
                        <X className="w-6 h-6" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-3">
                        Question Text
                      </label>
                      <textarea
                        value={questionText}
                        onChange={(e) => setQuestionText(e.target.value)}
                        rows={4}
                        className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90 resize-none text-lg"
                        placeholder="Enter your question here..."
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-4">
                        Answer Options
                      </label>
                      <div className="space-y-4">
                        {options.map((option, index) => (
                          <div key={index} className="flex gap-3 items-center p-4 bg-white/40 backdrop-blur-sm rounded-xl border border-gray-200">
                            <input
                              type="text"
                              value={option.text}
                              onChange={(e) => {
                                const newOptions = [...options];
                                newOptions[index] = { ...option, text: e.target.value };
                                setOptions(newOptions);
                              }}
                              className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                              placeholder={`Option ${index + 1}`}
                            />

                            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 bg-white/60 px-3 py-2 rounded-lg border border-gray-200">
                              <input
                                type="checkbox"
                                checked={option.correct || false}
                                onChange={(e) => {
                                  const newOptions = [...options];
                                  newOptions[index] = { ...option, correct: e.target.checked };
                                  setOptions(newOptions);
                                }}
                                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                              />
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Correct</span>
                            </label>

                            <button
                              type="button"
                              onClick={() => {
                                setOptions(options.filter((_, i) => i !== index));
                              }}
                              className="p-2 text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 rounded-lg border border-red-200 hover:border-red-300 transition-all duration-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}

                        <button
                          type="button"
                          onClick={() =>
                            setOptions([...options, { text: '', correct: false }])
                          }
                          className="w-full px-6 py-4 text-indigo-600 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border-2 border-dashed border-indigo-200 hover:border-indigo-400 hover:from-indigo-100 hover:to-purple-100 transition-all duration-300 flex items-center justify-center space-x-2 font-medium"
                        >
                          <Plus className="w-5 h-5" />
                          <span>Add Option</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-3">
                        Question Tags
                      </label>
                      <div className="flex flex-wrap gap-3 mb-4">
                        {tags.map((tag) => (
                          <span
                            key={tag}
                            className="inline-flex items-center px-4 py-2 rounded-xl text-sm font-medium bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 border border-indigo-200 shadow-sm"
                          >
                            <Hash className="w-3 h-3 mr-1" />
                            {tag}
                            <button
                              type="button"
                              onClick={() => setTags(tags.filter(t => t !== tag))}
                              className="ml-2 text-indigo-600 hover:text-indigo-800"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                      <input
                        type="text"
                        placeholder="Add tags (press Enter)"
                        className="w-full px-6 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const newTag = e.target.value.trim();
                            if (newTag && !tags.includes(newTag)) {
                              setTags([...tags, newTag]);
                              e.target.value = '';
                            }
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button
                      type="submit"
                      className="flex-1 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center space-x-2 text-lg font-semibold"
                    >
                      <Save className="w-5 h-5" />
                      <span>Save Question</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditMode('test');
                        setActiveQuestion(null);
                        setIsNewQuestion(false);
                      }}
                      className="px-8 py-4 bg-white/60 text-gray-700 rounded-xl hover:bg-white/80 transition-all duration-300 border border-gray-200 hover:border-gray-300 flex items-center justify-center space-x-2 font-semibold"
                    >
                      <X className="w-5 h-5" />
                      <span>Cancel</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}