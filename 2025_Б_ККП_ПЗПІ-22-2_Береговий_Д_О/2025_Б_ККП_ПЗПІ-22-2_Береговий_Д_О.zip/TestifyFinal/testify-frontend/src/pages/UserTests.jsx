import { useNavigate } from 'react-router-dom'
import { useState, useEffect, useMemo } from 'react'
import { testService } from '../services/testService'
import { MOCK_TESTS, MOCK_USER } from '../mocks'
import { Search, BookOpen, User, LogOut, Filter, Star, Clock, Hash, Edit3, Play, Trophy } from 'lucide-react'
import Navbar from '../components/Navbar'
import TestConfirmModal from '../components/TestConfirmModal'

function UserTests() {
  const navigate = useNavigate()
  const [showMenu, setShowMenu] = useState(false)
  const [tests, setTests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [userName, setUserName] = useState(MOCK_USER.name)
  
  // Modal state
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [selectedTest, setSelectedTest] = useState(null)
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedTags, setSelectedTags] = useState([])
  const [difficultyFilter, setDifficultyFilter] = useState('all')
  const [sortBy, setSortBy] = useState('title') // 'title', 'questions', 'newest'

  // Get unique tags from all tests
  const availableTags = useMemo(() => {
    const tags = new Set()
    tests.forEach(test => {
      test.tags?.forEach(tag => tags.add(tag))
    })
    return Array.from(tags)
  }, [tests])

  useEffect(() => {
    const fetchTests = async () => {
      try {
        setLoading(true)
        const data = await testService.getUserTests()
        setTests(data)
      } catch (err) {
        console.error('Failed to fetch tests, using mock data:', err)
        setTests(MOCK_TESTS)
        setError(null) // Clear error since we're using mock data
      } finally {
        setLoading(false)
      }
    }

    fetchTests()
  }, [])

  // Filter and sort tests
  const filteredTests = useMemo(() => {
    return tests
      .filter(test => {
        const matchesSearch = test.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            test.description?.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesTags = selectedTags.length === 0 || 
                           selectedTags.every(tag => test.tags?.includes(tag))
        return matchesSearch && matchesTags
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'questions':
            return b.question_amount - a.question_amount
          case 'newest':
            return b.id - a.id
          default: // 'title'
            return a.title.localeCompare(b.title)
        }
      })
  }, [tests, searchTerm, selectedTags, sortBy])

  const toggleTag = (tag) => {
    setSelectedTags(prev => 
      prev.includes(tag)
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    )
  }

  const handleTestClick = (test) => {
    setSelectedTest(test)
    setShowConfirmModal(true)
  }

  const handleStartTest = () => {
    if (selectedTest) {
      navigate(`/tests/${selectedTest.test_id}`)
    }
    setShowConfirmModal(false)
    setSelectedTest(null)
  }

  const handleCancelTest = () => {
    setShowConfirmModal(false)
    setSelectedTest(null)
  }

  if (loading) return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
      <div className="text-center">
        <div className="relative mb-6">
          <div className="w-16 h-16 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-pulse"></div>
            <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="h-4 bg-gray-200 rounded-full w-48 mx-auto animate-pulse"></div>
          <div className="h-3 bg-gray-200 rounded-full w-32 mx-auto animate-pulse"></div>
        </div>
      </div>
    </div>
  )

  if (error) return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white flex items-center justify-center">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md mx-4 border border-red-100">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Something went wrong</h3>
          <p className="text-red-600">Error: {error}</p>
        </div>
      </div>
    </div>
  )

  console.log(tests)
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>

      {/* Header */}
      <Navbar 
        title="My Tests"
        icon={Trophy}
        userName={userName}
        showBackButton={true}
        backButtonPath="/home"
      />

      {/* Confirmation Modal */}
      <TestConfirmModal
        isOpen={showConfirmModal}
        test={selectedTest}
        onConfirm={handleStartTest}
        onCancel={handleCancelTest}
      />

      {/* Main Content */}
      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          {/* <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome back, <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{userName.split(' ')[0]}</span>! 👋
          </h2> */}
          <p className="text-xl text-gray-600">Watch tests you created and edit them!</p>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-4 sm:space-y-0">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search tests, topics, descriptions..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                  />
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white/70 backdrop-blur-sm hover:bg-white/90 transition-all duration-300"
                >
                  <option value="title">Sort by Title</option>
                  <option value="questions">Sort by Questions</option>
                  <option value="newest">Sort by Newest</option>
                </select>
              </div>
            </div>

            {/* Tags */}
            {availableTags.length > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-200/50">
                <div className="flex items-center space-x-2 mb-3">
                  <Hash className="w-4 h-4 text-gray-500" />
                  <span className="text-sm font-medium text-gray-600">Filter by tags:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {availableTags.map(tag => (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                        selectedTags.includes(tag)
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                          : 'bg-white/60 text-gray-700 hover:bg-white/80 border border-gray-200 hover:border-indigo-300'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Test Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTests.map((test, index) => (
            <div
              key={test.id}
              className="group bg-white/80 backdrop-blur-md rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 p-6 cursor-pointer border border-white/20 hover:border-indigo-200 transform hover:scale-105 hover:-translate-y-2"
              onClick={() => handleTestClick(test)}
              style={{animationDelay: `${index * 100}ms`}}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                  <Play className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-center space-x-1 bg-white/60 rounded-full px-2 py-1">
                  <Clock className="w-3 h-3 text-gray-500" />
                  <span className="text-xs text-gray-600">{test.question_amount}q</span>
                </div>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-indigo-600 transition-colors duration-300">
                {test.title}
              </h3>
              
              <p className="text-gray-600 mb-4 line-clamp-2 leading-relaxed">
                {test.description || 'No description available'}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {test.tags?.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 border border-indigo-200"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              
              <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                <div className="flex items-center space-x-1">
                  <span className="text-sm font-medium text-gray-900">{test.question_amount}</span>
                  <span className="text-sm text-gray-500">questions</span>
                </div>
                <button
                  className="inline-flex items-center space-x-1 text-indigo-600 hover:text-indigo-800 font-medium text-sm bg-indigo-50 hover:bg-indigo-100 px-3 py-1 rounded-lg transition-all duration-300 hover:shadow-md"
                  onClick={(e) => {
                    e.stopPropagation()
                    navigate(`/tests/${test.test_id}/edit`)
                  }}
                >
                  <Edit3 className="w-3 h-3" />
                  <span>Edit</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredTests.length === 0 && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="w-12 h-12 text-indigo-400" />
            </div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-3">
              No tests found
            </h3>
            <p className="text-gray-500 text-lg max-w-md mx-auto">
              Try adjusting your search or filters to discover more tests, or create your own!
            </p>
          </div>
        )}
      </main>
    </div>
  )
}

export default UserTests