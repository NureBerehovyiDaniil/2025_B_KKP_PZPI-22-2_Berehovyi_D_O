
import { useEffect, useState } from "react";
import { Upload, FileText, Edit3, Save, Download, ArrowLeft, Plus, File, Search, Trophy } from 'lucide-react';
import Navbar from "../components/Navbar";

export default function UploadNewTest() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");

  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [fileContent, setFileContent] = useState("");
  const [saving, setSaving] = useState(false);

  const [jsonFilename, setJsonFilename] = useState("text_final.json");

  const API_BASE = "http://localhost:4000";


  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setMessage("");
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage("Please select a file to upload.");
      return;
    }
    setUploading(true);
    setMessage("");

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch(`${API_BASE}/api/upload`, {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.detail || "Upload failed.");
      }

      const result = await res.json();
      setMessage(result.message || "Upload successful!");
      setFile(null);
      setFileContent(result.text)
      setSelectedFile(true)
      if (result.filename) {
        await loadFileContent(result.filename);
      }
    } catch (err) {
      console.error("Error during upload:", err);
      setMessage(err.message || "Upload failed.");
    } finally {
      setUploading(false);
    }
  };

  const loadFileContent = async (filename) => {
    try {
      const res = await fetch(`${API_BASE}/api/files/${filename}`);
      if (!res.ok) throw new Error("Failed to load file content from server.");

      const data = await res.json();
      setSelectedFile(filename);
      setTitle(data.title || "");
      setDescription(data.description || "");
      setFileContent(data.content || "");
      setMessage("");
    } catch (err) {
      console.error("Error loading file content:", err);
      setMessage("Failed to load file content.");
    }
  };

  const saveFileContent = async () => {
    if (!selectedFile) {
      setMessage("No file selected to save changes.");
      return;
    }
    setSaving(true);
    setMessage("");

    try {
      const res = await fetch(`${API_BASE}/api/files`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: title, description: description, content: fileContent }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.detail || "Failed to save file changes.");
      }

      const result = await res.json();
      setMessage(result.message || "File changes saved successfully!");
    } catch (err) {
      console.error("Error saving file content:", err);
      setMessage(err.message || "Failed to save file changes.");
    } finally {
      setSaving(false);
    }
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>

      {/* Header */}
      <Navbar 
        title="Upload New Test"
        icon={Upload}
        showBackButton={true}
        backButtonPath="/home"
      />

      {/* Main Content */}
      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Create & <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Upload Tests</span> 📚
          </h2>
          <p className="text-xl text-gray-600">Upload files and create amazing tests for your students</p>
        </div>

        {/* Upload Section */}
        <div className="mb-8">
          <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                <Upload className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900">Upload New File</h3>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">Select File</label>
                <input
                  type="file"
                  onChange={handleFileChange}
                  className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                />
              </div>
              <button
                onClick={handleUpload}
                disabled={!file || uploading}
                className={`px-8 py-3 rounded-xl text-white font-medium transition-all duration-300 transform hover:scale-105 ${
                  uploading || !file
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl"
                }`}
              >
                {uploading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Uploading...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Upload className="w-4 h-4" />
                    <span>Upload File</span>
                  </div>
                )}
              </button>
            </div>
          </div>
        </div>



        {/* Editor Section */}
        {selectedFile && (
          <div className="mb-8">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8">
              <div className="flex items-center space-x-3 mb-8">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Edit3 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-semibold text-gray-900">File Editor</h3>
                  <p className="text-indigo-600 font-medium">{selectedFile}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                  <input
                    type="text"
                    placeholder="Enter test title..."
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                  />
                </div>
               
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  placeholder="Enter test description..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-3 border border-gray-200 rounded-xl h-24 resize-y focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                />
              </div>

              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-700 mb-2">File Content</label>
                <textarea
                  placeholder="Enter or paste your test content here..."
                  className="w-full h-96 p-4 border border-gray-200 rounded-xl font-mono text-sm resize-y focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                  value={fileContent}
                  onChange={(e) => setFileContent(e.target.value)}
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={saveFileContent}
                  disabled={saving}
                  className={`flex-1 px-6 py-3 rounded-xl text-white font-medium transition-all duration-300 transform hover:scale-105 ${
                    saving
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-lg hover:shadow-xl"
                  }`}
                >
                  {saving ? (
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Saving...</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center space-x-2">
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </div>
                  )}
                </button>

              </div>

              <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                <p className="text-sm text-purple-700">
                  <strong>Export Info:</strong> This will save your current content as <code className="bg-purple-100 px-1 rounded">text_final.txt</code> in the backend's output directory.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Message Display */}
        {message && (
          <div className="fixed top-20 right-4 z-50 animate-pulse">
            <div className={`p-4 rounded-xl shadow-lg text-white font-medium ${
              message.includes('successful') || message.includes('saved')
                ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                : 'bg-gradient-to-r from-red-500 to-rose-500'
            }`}>
              {message}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}