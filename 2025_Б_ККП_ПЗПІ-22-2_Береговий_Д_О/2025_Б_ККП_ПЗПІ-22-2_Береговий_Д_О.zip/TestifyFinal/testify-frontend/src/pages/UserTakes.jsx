import { useNavigate } from 'react-router-dom'
import { useState, useEffect, useMemo } from 'react'
import { testService } from '../services/testService'
import { MOCK_USER } from '../mocks'
import { Search, BookOpen, Trophy, Clock, Hash, Calendar, CheckCircle, Star } from 'lucide-react'
import Navbar from '../components/Navbar'
import Loading from '../components/Loading'

function UserTakes() {
  const navigate = useNavigate()
  const [userTakes, setUserTakes] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [userName, setUserName] = useState(MOCK_USER.name)
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedTags, setSelectedTags] = useState([])
  const [sortBy, setSortBy] = useState('newest') // 'newest', 'oldest', 'title', 'score'

  // Get unique tags from all takes
  const availableTags = useMemo(() => {
    const tags = new Set()
    userTakes.forEach(take => {
      take.tags?.forEach(tag => tags.add(tag))
    })
    return Array.from(tags)
  }, [userTakes])

  useEffect(() => {
    const fetchUserTakes = async () => {
      try {
        setLoading(true)
        const data = await testService.getUserTakes()
        setUserTakes(data)
      } catch (err) {
        console.error('Failed to fetch user takes:', err)
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserTakes()
  }, [])

  // Filter and sort takes
  const filteredTakes = useMemo(() => {
    return userTakes
      .filter(take => {
        const matchesSearch = take.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            take.description?.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesTags = selectedTags.length === 0 || 
                           selectedTags.every(tag => take.tags?.includes(tag))
        return matchesSearch && matchesTags
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'oldest':
            return new Date(a.completed_at) - new Date(b.completed_at)
          case 'title':
            return a.title.localeCompare(b.title)
          default: // 'newest'
            return new Date(b.completed_at) - new Date(a.completed_at)
        }
      })
  }, [userTakes, searchTerm, selectedTags, sortBy])

  const toggleTag = (tag) => {
    setSelectedTags(prev => 
      prev.includes(tag)
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    )
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600 bg-green-100'
    if (score >= 60) return 'text-yellow-600 bg-yellow-100'
    return 'text-red-600 bg-red-100'
  }

  const handleTakeClick = (takeId) => {
    navigate(`/my-takes/${takeId}`)
  }

  if (loading) return <Loading message="Loading your test history..." submessage="Fetching your performance data" />

  if (error) return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white flex items-center justify-center">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md mx-4 border border-red-100">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Something went wrong</h3>
          <p className="text-red-600">Error: {error}</p>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>

      {/* Header */}
      <Navbar 
        title="My Takes"
        icon={Trophy}
        userName={userName}
        showBackButton={true}
        backButtonPath="/home"
      />

      {/* Main Content */}
      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Your Test <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">History</span> 📊
          </h2>
          <p className="text-xl text-gray-600">Track your progress and review your performance</p>
        </div>

        {/* Stats Overview */}
        {userTakes.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg border border-white/20 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Tests</p>
                  <p className="text-3xl font-bold text-gray-900">{userTakes.length}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg border border-white/20 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Average Score</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {Math.round(userTakes.reduce((acc, take) => acc + (take.res_count / take.questions_amount) * 100, 0) / userTakes.length)}%
                  </p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                  <Star className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
            <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg border border-white/20 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Questions</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {userTakes.reduce((acc, take) => acc + take.questions_amount, 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="mb-8">
          <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-4 sm:space-y-0">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search your test history..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/70 backdrop-blur-sm transition-all duration-300 hover:bg-white/90"
                  />
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white/70 backdrop-blur-sm hover:bg-white/90 transition-all duration-300"
                >
                  <option value="newest">Sort by Newest</option>
                  <option value="oldest">Sort by Oldest</option>
                  <option value="title">Sort by Title</option>
                  <option value="score">Sort by Score</option>
                </select>
              </div>
            </div>

            {/* Tags */}
            {availableTags.length > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-200/50">
                <div className="flex items-center space-x-2 mb-3">
                  <Hash className="w-4 h-4 text-gray-500" />
                  <span className="text-sm font-medium text-gray-600">Filter by tags:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {availableTags.map(tag => (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                        selectedTags.includes(tag)
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                          : 'bg-white/60 text-gray-700 hover:bg-white/80 border border-gray-200 hover:border-indigo-300'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Takes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTakes.map((take, index) => {
            const score = Math.round((take.res_count / take.questions_amount) * 100)
            return (
              <div
                key={take.id}
                onClick={() => handleTakeClick(take.id)}
                className="group bg-white/80 backdrop-blur-md rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 p-6 border border-white/20 hover:border-indigo-200 transform hover:scale-105 hover:-translate-y-2 cursor-pointer"
                style={{animationDelay: `${index * 100}ms`}}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                    <Trophy className="w-6 h-6 text-white" />
                  </div>
                  <div className={`flex items-center space-x-1 rounded-full px-3 py-1 ${getScoreColor(score)}`}>
                    <span className="text-sm font-semibold">{score}%</span>
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-indigo-600 transition-colors duration-300">
                  {take.title}
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-2 leading-relaxed">
                  {take.description || 'No description available'}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {take.tags?.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 border border-indigo-200"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="space-y-3 pt-4 border-t border-gray-100">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Score</span>
                    <span className="text-sm font-medium text-gray-900">
                      {take.res_count}/{take.questions_amount}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Completed</span>
                    <div className="flex items-center space-x-1 text-sm text-gray-600">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(take.completed_at)}</span>
                    </div>
                  </div>
                </div>

                {/* Click indicator */}
                <div className="mt-4 pt-4 border-t border-gray-100 text-center">
                  <span className="text-xs text-gray-500 group-hover:text-indigo-600 transition-colors duration-300">
                    Click to view details →
                  </span>
                </div>
              </div>
            )
          })}
        </div>

        {/* Empty State */}
        {filteredTakes.length === 0 && !loading && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-12 h-12 text-indigo-400" />
            </div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-3">
              {userTakes.length === 0 ? 'No tests taken yet' : 'No tests found'}
            </h3>
            <p className="text-gray-500 text-lg max-w-md mx-auto">
              {userTakes.length === 0 
                ? 'Start taking some tests to see your history here!'
                : 'Try adjusting your search or filters to find specific tests.'
              }
            </p>
            {userTakes.length === 0 && (
              <button
                onClick={() => navigate('/home')}
                className="mt-6 inline-flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl font-medium hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <BookOpen className="w-5 h-5" />
                <span>Browse Tests</span>
              </button>
            )}
          </div>
        )}
      </main>
    </div>
  )
}

export default UserTakes