import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { testService } from '../services/testService';
import { MOCK_TEST_RESULTS } from '../mocks';
import './TakeTest.css';

export default function TestResults() {
  const { testId } = useParams();
  const navigate = useNavigate();
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchResults = async () => {
      try {
        setLoading(true);
        const data = await testService.getTestResults(testId);
        setResults(data);
      } catch (err) {
        console.error('Failed to fetch test results, using mock data:', err);
        setResults(MOCK_TEST_RESULTS);
        setError(null); // Clear error since we're using mock data
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [testId]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-red-500">Error: {error}</div>
    </div>
  );

  if (!results) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold text-gray-900">Test Results</h1>
            <button
              onClick={() => navigate('/home')}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Back to Home
            </button>
          </div>

          {/* Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-sm text-blue-600 font-medium">Score</div>
              <div className="text-2xl font-bold text-blue-900">{results.score}%</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-sm text-green-600 font-medium">Correct</div>
              <div className="text-2xl font-bold text-green-900">{results.correct_answers}</div>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="text-sm text-red-600 font-medium">Incorrect</div>
              <div className="text-2xl font-bold text-red-900">{results.incorrect_answers}</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-600 font-medium">Time Taken</div>
              <div className="text-2xl font-bold text-gray-900">{results.time_taken}</div>
            </div>
          </div>
        </div>

        {/* Question Breakdown */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Question Breakdown</h2>
          <div className="space-y-6">
            {results.question_breakdown.map((item, index) => (
              <div
                key={item.question_id}
                className={`p-4 rounded-lg ${
                  item.is_correct ? 'bg-green-50' : 'bg-red-50'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-medium">
                    Question {index + 1}
                  </h3>
                  <span className="text-sm text-gray-500">
                    {item.time_taken} seconds
                  </span>
                </div>
                <p className="text-gray-800 mb-4">{item.question}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-600">Your Answer:</div>
                    <div className={`font-medium ${
                      item.is_correct ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {item.user_answer}
                    </div>
                  </div>
                  {!item.is_correct && (
                    <div>
                      <div className="text-sm text-gray-600">Correct Answer:</div>
                      <div className="font-medium text-green-600">
                        {item.correct_answer}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
