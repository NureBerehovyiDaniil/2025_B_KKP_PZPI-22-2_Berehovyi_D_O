import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { testService } from "../services/testService";
import { BookOpen, User, X, CheckCircle, Circle, ArrowRight, Home, Trophy, Sparkles, AlertTriangle } from 'lucide-react';

export default function TestTaking() {
  const { testId } = useParams();
  const navigate = useNavigate();
  const [question, setQuestion] = useState(null);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isTestComplete, setIsTestComplete] = useState(false);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [currentQuestionNumber, setCurrentQuestionNumber] = useState(1);
  const [showExitConfirmation, setShowExitConfirmation] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    let isMounted = true;

    const fetchTestData = async () => {
      try {
        setLoading(true);
        
        // Fetch both the first question and total questions amount
        const [questionData, questionsAmount] = await Promise.all([
          testService.startTest(testId),
          testService.getTestQuestionsAmount(testId)
        ]);
        
        if (isMounted) {
          setQuestion(questionData);
          setTotalQuestions(questionsAmount);
          setCurrentQuestionNumber(1);
        }
      } catch (err) {
        console.error("Failed to fetch test data:", err);
        if (isMounted) setError("Failed to load test data");
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchTestData();

    return () => {
      isMounted = false;
    };
  }, [testId]);

  const handleAnswerSelect = (answerId) => {
    setSelectedAnswers((prev) =>
      prev.includes(answerId)
        ? prev.filter((id) => id !== answerId)
        : [...prev, answerId]
    );
  };

  const handleAnswerSubmit = async () => {
    if (!question || selectedAnswers.length === 0) return;

    try {
      const response = await testService.submitAnswer(
        testId,
        question.id,
        selectedAnswers
      );

      if (response.next_question == "No more questions available") {
        setIsTestComplete(true);
      } else if (response.next_question) {
        setQuestion(response.next_question);
        setSelectedAnswers([]);
        setCurrentQuestionNumber(prev => prev + 1);
      } else {
        throw new Error("Unexpected response format");
      }
    } catch (err) {
      console.error("Failed to submit answer:", err);
      setError("Failed to submit answer");
    }
  };

  const handleExitTest = () => {
    setShowExitConfirmation(true);
  };

  const confirmExitTest = async () => {
    try {
      setIsExiting(true);
      await testService.endTest(testId);
      navigate("/home");
    } catch (err) {
      console.error("Failed to end test:", err);
      setError("Failed to end test");
      setIsExiting(false);
    }
  };

  const cancelExitTest = () => {
    setShowExitConfirmation(false);
  };

  if (loading) return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>
      
      <div className="text-center relative">
        <div className="relative mb-8">
          <div className="w-20 h-20 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-pulse"></div>
            <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
          </div>
        </div>
        <div className="space-y-3">
          <div className="h-6 bg-gradient-to-r from-indigo-200 to-purple-200 rounded-full w-64 mx-auto animate-pulse"></div>
          <div className="h-4 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full w-48 mx-auto animate-pulse"></div>
          <div className="h-4 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full w-32 mx-auto animate-pulse"></div>
        </div>
        <p className="text-lg text-gray-600 mt-6 font-medium">Loading your test...</p>
      </div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-pink-50 flex items-center justify-center">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-red-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>
      
      <div className="bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl p-10 max-w-md mx-4 border border-white/30 relative">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <X className="w-10 h-10 text-red-500" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Oops! Something went wrong</h3>
          <p className="text-red-600 mb-6 text-lg">{error}</p>
          <button
            onClick={() => navigate("/home")}
            className="px-8 py-3 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl hover:from-red-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-semibold"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );

  if (!question) return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>
      
      <div className="bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl p-10 max-w-md mx-4 border border-white/30 relative">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
            <BookOpen className="w-10 h-10 text-gray-500" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Test Not Found</h3>
          <p className="text-gray-600 mb-6 text-lg">The test you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => navigate("/home")}
            className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-semibold"
          >
            Back to Home
          </button>
        </div>
      </div>
    </div>
  );

  if (isTestComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
        {/* Floating background elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-emerald-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-teal-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        {/* Header */}
        <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                  Test Complete!
                </h1>
              </div>
            </div>
          </div>
        </header>

        <div className="relative flex items-center justify-center min-h-[calc(100vh-88px)] px-4">
          <div className="bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl p-12 max-w-2xl mx-auto text-center border border-white/30 relative overflow-hidden">
            {/* Celebration sparkles */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <Sparkles className="absolute top-4 left-4 w-6 h-6 text-yellow-400 animate-pulse" />
              <Sparkles className="absolute top-8 right-8 w-4 h-4 text-pink-400 animate-pulse" style={{animationDelay: '0.5s'}} />
              <Sparkles className="absolute bottom-6 left-8 w-5 h-5 text-blue-400 animate-pulse" style={{animationDelay: '1s'}} />
              <Sparkles className="absolute bottom-4 right-6 w-6 h-6 text-purple-400 animate-pulse" style={{animationDelay: '1.5s'}} />
            </div>

            <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl animate-bounce">
              <Trophy className="w-12 h-12 text-white" />
            </div>
            
            <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Congratulations! 🎉
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              You have successfully completed all questions in this test. Great job on finishing the challenge!
            </p>
            
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 mb-8 border border-green-200">
              <h3 className="text-lg font-semibold text-green-800 mb-2">What's Next?</h3>
              <p className="text-green-700">Ready to take on more challenges? Head back to explore other tests and continue your learning journey.</p>
            </div>
            
            <button
              onClick={() => navigate("/home")}
              className="group inline-flex items-center space-x-3 px-10 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-2xl font-semibold text-lg"
            >
              <Home className="w-6 h-6 group-hover:animate-bounce" />
              <span>Back to Tests</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirmation && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl p-8 max-w-md w-full border border-white/30 relative">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-red-100 to-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Exit Test?</h3>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                Are you sure you want to end the test now? Your progress will be lost and you'll be redirected to the home page.
              </p>
              
              <div className="flex space-x-4">
                <button
                  onClick={cancelExitTest}
                  disabled={isExiting}
                  className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-xl hover:bg-gray-300 transition-all duration-300 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmExitTest}
                  disabled={isExiting}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-xl hover:from-red-700 hover:to-red-800 transition-all duration-300 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isExiting ? "Exiting..." : "Yes, Exit"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Test in Progress
              </h1>
            </div>
            <button
              onClick={handleExitTest}
              className="flex items-center space-x-2 bg-white/70 backdrop-blur-sm rounded-xl px-4 py-2 hover:bg-white/90 transition-all duration-300 border border-white/30 shadow-lg hover:shadow-xl transform hover:scale-105 text-gray-700 font-medium"
            >
              <X className="w-4 h-4" />
              <span>Exit Test</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl border border-white/30 overflow-hidden">
          {/* Question Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">
                  Question {currentQuestionNumber}
                  {totalQuestions > 0 && (
                    <span className="text-white/80"> of {totalQuestions}</span>
                  )}
                </h2>
                <p className="text-white/70 text-sm">Choose the best answer(s)</p>
              </div>
              {totalQuestions > 0 && (
                <div className="text-right">
                  <div className="text-white text-sm font-medium mb-1">
                    {Math.round(((currentQuestionNumber - 1) / totalQuestions) * 100)}% Complete
                  </div>
                  <div className="w-24 h-2 bg-white/30 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-white rounded-full transition-all duration-500 ease-out"
                      style={{ width: `${((currentQuestionNumber - 1) / totalQuestions) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-white/60 rounded-full"></div>
              <div className="flex-1 h-1 bg-white/30 rounded-full">
                <div 
                  className="h-full bg-white rounded-full transition-all duration-500 ease-out"
                  style={{ width: totalQuestions > 0 ? `${((currentQuestionNumber - 1) / totalQuestions) * 100}%` : '0%' }}
                ></div>
              </div>
              <span className="text-white/80 text-sm font-medium">In Progress</span>
            </div>
          </div>

          {/* Question Content */}
          <div className="p-8">
            <h3 className="text-3xl font-bold text-gray-900 mb-8 leading-relaxed">
              {question.question}
            </h3>

            <div className="space-y-4 mb-8">
              {question.options.map((option, index) => (
                <label
                  key={option.id}
                  className={`group block p-6 rounded-2xl border-2 cursor-pointer transition-all duration-300 transform hover:scale-[1.02] ${
                    selectedAnswers.includes(option.id)
                      ? "border-indigo-500 bg-gradient-to-r from-indigo-50 to-purple-50 shadow-lg"
                      : "border-gray-200 hover:border-indigo-300 bg-white/60 hover:bg-white/80 hover:shadow-md"
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    {selectedAnswers.includes(option.id) ? (
                      <CheckCircle className="w-6 h-6 text-indigo-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <Circle className="w-6 h-6 text-gray-400 group-hover:text-indigo-400 flex-shrink-0 mt-0.5 transition-colors duration-300" />
                    )}
                    <div className="flex-1">
                      <span className={`text-lg font-medium leading-relaxed ${
                        selectedAnswers.includes(option.id) 
                          ? "text-indigo-900" 
                          : "text-gray-700 group-hover:text-gray-900"
                      }`}>
                        {option.text}
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={selectedAnswers.includes(option.id)}
                      onChange={() => handleAnswerSelect(option.id)}
                      className="sr-only"
                    />
                  </div>
                </label>
              ))}
            </div>

            {/* Submit Button */}
            <div className="flex justify-end pt-6 border-t border-gray-200/50">
              <button
                onClick={handleAnswerSubmit}
                disabled={selectedAnswers.length === 0}
                className={`group inline-flex items-center space-x-3 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 transform ${
                  selectedAnswers.length === 0
                    ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                    : "bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 hover:scale-105 shadow-lg hover:shadow-2xl"
                }`}
              >
                <span>Submit Answer</span>
                <ArrowRight className={`w-5 h-5 transition-transform duration-300 ${
                  selectedAnswers.length > 0 ? "group-hover:translate-x-1" : ""
                }`} />
              </button>
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-white/70 backdrop-blur-sm rounded-full px-6 py-3 border border-white/30 shadow-lg">
            <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-gray-700">
              {selectedAnswers.length > 0 
                ? `${selectedAnswers.length} answer${selectedAnswers.length > 1 ? 's' : ''} selected`
                : "Select your answer(s) to continue"
              }
              {totalQuestions > 0 && (
                <span className="ml-2 text-gray-500">• Question {currentQuestionNumber} of {totalQuestions}</span>
              )}
            </span>
          </div>
        </div>
      </main>
    </div>
  );
}