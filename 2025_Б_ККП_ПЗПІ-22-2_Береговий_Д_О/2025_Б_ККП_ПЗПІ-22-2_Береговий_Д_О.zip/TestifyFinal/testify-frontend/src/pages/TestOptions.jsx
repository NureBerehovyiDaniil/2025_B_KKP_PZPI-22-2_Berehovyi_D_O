import { useNavigate, useParams } from 'react-router-dom'
import { useState } from 'react'
import './TestOptions.css'

function TestOptions() {
  const navigate = useNavigate()
  const { id } = useParams()
  const [showMenu, setShowMenu] = useState(false)

  const handleTake = () => {
    navigate(`/test/${id}/take`)
  }

  const handleEdit = () => {
    navigate(`/test/${id}/edit`)
  }

  const handleLogout = () => {
    // Здесь можно очистить токен, session и т.д.
    navigate('/')
  }

  const toggleMenu = () => {
    setShowMenu((prev) => !prev)
  }

  return (
    <div className="test-options-page">
      <header className="test-options-header">
        <div className="logo">Testify</div>
        <div className="avatar-wrapper">
          <img
            src="https://www.svgrepo.com/show/7025/avatar.svg"
            alt="Avatar"
            className="avatar"
            onClick={toggleMenu}
          />
          {showMenu && (
            <div className="dropdown-menu">
              <button onClick={handleLogout}>Log Out</button>
            </div>
          )}
        </div>
      </header>

      <div className="test-options-content">
        <h2>Test #{id}</h2>
        <button onClick={handleTake}>Take Test</button>
        <button onClick={handleEdit}>Edit Test</button>
      </div>
    </div>
  )
}

export default TestOptions
