import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { testService } from "../services/testService";
import {
  ArrowLeft,
  User,
  LogOut,
  BookOpen,
  Trophy,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Hash,
  Calendar,
} from "lucide-react";

function UserTakeDetails() {
  const [showMenu, setShowMenu] = useState(false);
  const [takeDetails, setTakeDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userName, setUserName] = useState("John Doe");
  const { takeId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTakeDetails = async () => {
      try {
        setLoading(true);
        // Get take ID from URL parameters or props
        const data = await testService.getUserTakeDetails(takeId);
        setTakeDetails(data);
      } catch (err) {
        console.error("Failed to fetch take details:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (takeId) {
      fetchTakeDetails();
    }
  }, [takeId]);

  const handleLogout = () => {
    // Implement logout logic here
    navigate("/login");
  };

  const handleBackToTakes = () => {
    navigate("/my-takes");
  };

  const handleHomeNavigation = () => {
    navigate("/");
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600 bg-green-100";
    if (score >= 60) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const isCorrectAnswer = (question, selectedAnswers) => {
    const correctAnswers =
      question.options
        ?.filter((option) => option.correct)
        .map((option) => option.id) || [];
    if (correctAnswers.length !== selectedAnswers.length) return false;
    return correctAnswers.every((id) => selectedAnswers.includes(id));
  };

  const getAnswerStatus = (question, selectedAnswers) => {
    if (selectedAnswers.length === 0) return "skipped";
    return isCorrectAnswer(question, selectedAnswers) ? "correct" : "incorrect";
  };

  if (loading)
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="relative mb-6">
            <div className="w-16 h-16 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-pulse"></div>
              <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-4 bg-gray-200 rounded-full w-48 mx-auto animate-pulse"></div>
            <div className="h-3 bg-gray-200 rounded-full w-32 mx-auto animate-pulse"></div>
          </div>
        </div>
      </div>
    );

  if (error)
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-white flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md mx-4 border border-red-100">
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                className="w-8 h-8 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Something went wrong
            </h3>
            <p className="text-red-600">Error: {error}</p>
            <button
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );

  if (!takeDetails) return null;

  const score = Math.round(
    (takeDetails.res_count / takeDetails.questions_amount) * 100
  );
  const correctAnswers = takeDetails.res_count;
  const incorrectAnswers =
    takeDetails.questions?.filter((q) => {
      const status = getAnswerStatus(q, q.selected_answers || []);
      return status === "incorrect";
    }).length || 0;
  const skippedAnswers =
    takeDetails.questions?.filter((q) => {
      const status = getAnswerStatus(q, q.selected_answers || []);
      return status === "skipped";
    }).length || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Floating background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div
          className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/3 left-1/3 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"
          style={{ animationDelay: "4s" }}
        ></div>
      </div>

      {/* Header */}
      <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <button
                onClick={handleBackToTakes}
                className="w-10 h-10 bg-white/70 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 border border-white/30 hover:bg-white/90"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Test Details
              </h1>
            </div>
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="flex items-center space-x-3 bg-white/70 backdrop-blur-sm rounded-xl px-4 py-2 hover:bg-white/90 transition-all duration-300 border border-white/30 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <span className="text-gray-700 font-medium">{userName}</span>
                <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
              </button>
              {showMenu && (
                <div className="absolute right-0 mt-2 w-48 rounded-xl shadow-2xl bg-white/95 backdrop-blur-md border border-white/20 overflow-hidden">
                  <button
                    onClick={handleHomeNavigation}
                    className="block w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-indigo-50 hover:to-purple-50 transition-all duration-200 flex items-center space-x-2"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>Home</span>
                  </button>
                  <button
                    onClick={handleBackToTakes}
                    className="block w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-indigo-50 hover:to-purple-50 transition-all duration-200 flex items-center space-x-2"
                  >
                    <Trophy className="w-4 h-4" />
                    <span>My Takes</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-indigo-50 hover:to-purple-50 transition-all duration-200 flex items-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Log Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Test Overview */}
        <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 p-8 mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
            <div className="flex-1 mb-4 lg:mb-0">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {takeDetails.title}
              </h2>
              <p className="text-lg text-gray-600 mb-4">
                {takeDetails.description}
              </p>

              {/* Tags */}
              {takeDetails.tags && takeDetails.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {takeDetails.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800 border border-indigo-200"
                    >
                      <Hash className="w-3 h-3 mr-1" />
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              <div className="flex items-center space-x-1 text-gray-500">
                <Calendar className="w-4 h-4" />
                <span>Completed on {formatDate(takeDetails.completed_at)}</span>
              </div>
            </div>

            <div
              className={`flex items-center justify-center w-32 h-32 rounded-2xl ${getScoreColor(
                score
              )} text-center`}
            >
              <div>
                <div className="text-4xl font-bold">{score}%</div>
                <div className="text-sm font-medium opacity-80">
                  Final Score
                </div>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/30">
              <div className="text-center">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {takeDetails.questions_amount}
                </div>
                <div className="text-sm text-gray-600">Total Questions</div>
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/30">
              <div className="text-center">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {correctAnswers}
                </div>
                <div className="text-sm text-gray-600">Correct</div>
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/30">
              <div className="text-center">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <XCircle className="w-4 h-4 text-red-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {incorrectAnswers}
                </div>
                <div className="text-sm text-gray-600">Incorrect</div>
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/30">
              <div className="text-center">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <AlertCircle className="w-4 h-4 text-gray-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900">
                  {skippedAnswers}
                </div>
                <div className="text-sm text-gray-600">Skipped</div>
              </div>
            </div>
          </div>
        </div>

        {/* Questions Review */}
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">
            Question Review
          </h3>

          {takeDetails.questions?.map((question, index) => {
            const status = getAnswerStatus(
              question,
              question.selected_answers || []
            );
            const correctOptions =
              question.options?.filter((option) => option.correct) || [];

            return (
              <div
                key={question.id}
                className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg border border-white/20 p-6 hover:shadow-xl transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        status === "correct"
                          ? "bg-green-100 text-green-600"
                          : status === "incorrect"
                          ? "bg-red-100 text-red-600"
                          : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {index + 1}
                    </div>
                    <h4 className="text-lg font-semibold text-gray-900">
                      Question {index + 1}
                    </h4>
                  </div>

                  <div
                    className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium ${
                      status === "correct"
                        ? "bg-green-100 text-green-600"
                        : status === "incorrect"
                        ? "bg-red-100 text-red-600"
                        : "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {status === "correct" && (
                      <CheckCircle className="w-4 h-4" />
                    )}
                    {status === "incorrect" && <XCircle className="w-4 h-4" />}
                    {status === "skipped" && (
                      <AlertCircle className="w-4 h-4" />
                    )}
                    <span className="capitalize">{status}</span>
                  </div>
                </div>

                <div className="mb-6">
                  <p className="text-gray-900 text-lg leading-relaxed">
                    {question.question}
                  </p>
                </div>

                <div className="space-y-3">
                  {question.options?.map((option) => {
                    const isSelected = question.selected_answers?.includes(
                      option.id
                    );
                    const isCorrect = option.correct;

                    // Fixed styling logic - removed text-current class that was causing invisible text
                    let optionClasses = "p-4 rounded-xl border transition-all duration-200 ";
                    
                    if (isSelected && isCorrect) {
                      optionClasses += "bg-green-50 border-green-200 text-green-800";
                    } else if (isSelected && !isCorrect) {
                      optionClasses += "bg-red-50 border-red-200 text-red-800";
                    } else if (!isSelected && isCorrect) {
                      optionClasses += "bg-blue-50 border-blue-200 text-blue-800";
                    } else {
                      optionClasses += "bg-gray-50 border-gray-200 text-gray-700";
                    }

                    return (
                      <div key={option.id} className={optionClasses}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                                isSelected
                                  ? "border-current"
                                  : "border-gray-300"
                              }`}
                            >
                              {isSelected && (
                                <div className="w-3 h-3 rounded-full bg-current"></div>
                              )}
                            </div>
                            <span className="font-medium">{option.text}</span>
                          </div>

                          <div className="flex items-center space-x-2">
                            {isSelected && (
                              <span className="text-xs font-medium px-2 py-1 rounded-full bg-white bg-opacity-60 text-current">
                                Your Answer
                              </span>
                            )}
                            {isCorrect && (
                              <span className="text-xs font-medium px-2 py-1 rounded-full bg-green-100 text-green-600">
                                Correct
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}

export default UserTakeDetails;