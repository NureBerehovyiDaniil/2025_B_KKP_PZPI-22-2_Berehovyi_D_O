import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function AuthForm({ type }) {
  const isLogin = type === 'login'
  const navigate = useNavigate()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!email || !password || (!isLogin && password !== confirmPassword)) {
      alert('Please fill out all fields correctly.')
      return
    }

    alert(`${isLogin ? 'Login' : 'Registration'} successful!`)
    navigate('/')
  }

  return (
    <div className="page">
      <div className="container">
        <h2>{isLogin ? 'Login' : 'Register'}</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {!isLogin && (
            <input
              type="password"
              placeholder="Confirm password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          )}
          <button type="submit">
            {isLogin ? 'Sign In' : 'Sign Up'}
          </button>
        </form>
        <div className="link">
          {isLogin ? (
            <p>Don't have an account? <a href="/register">Sign up</a></p>
          ) : (
            <p>Already have an account? <a href="/">Sign in</a></p>
          )}
        </div>
      </div>
    </div>
  )
}

export default AuthForm
