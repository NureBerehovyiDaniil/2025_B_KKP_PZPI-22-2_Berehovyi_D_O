function Loading({ message = "Loading...", submessage = "Please wait" }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
      <div className="text-center">
        <div className="relative mb-6">
          <div className="w-16 h-16 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-pulse"></div>
            <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="h-4 bg-gray-200 rounded-full w-48 mx-auto animate-pulse"></div>
          <div className="h-3 bg-gray-200 rounded-full w-32 mx-auto animate-pulse"></div>
        </div>
        <div className="mt-4 space-y-1">
          <p className="text-lg font-medium text-gray-900">{message}</p>
          <p className="text-sm text-gray-600">{submessage}</p>
        </div>
      </div>
    </div>
  )
}

export default Loading