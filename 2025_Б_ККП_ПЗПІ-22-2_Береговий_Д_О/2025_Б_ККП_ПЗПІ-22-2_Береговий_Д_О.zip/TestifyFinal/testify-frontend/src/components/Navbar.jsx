import { useState, useEffect } from "react";
import {
  BookOpen,
  User,
  LogOut,
  ArrowLeft,
  Trophy,
  FileText,
  Award,
  Loader2,
  Settings,
  X,
  Save,
  Mail,
  UserCircle,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

function Navbar({
  title,
  icon: Icon,
  showBackButton = false,
  backButtonPath = "/home",
  menuItems = [], // Array of { label, icon, onClick } objects
}) {
  const [showMenu, setShowMenu] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState(null);
  const [profileSuccess, setProfileSuccess] = useState(false);
  const [profileForm, setProfileForm] = useState({
    username: "",
    email: "",
  });
  const navigate = useNavigate();

  // Fetch user data on component mount
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        const response = await fetch("http://localhost:8000/users/me", {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        setUserData(data);
        setProfileForm({
          username: data.username || "",
          email: data.email || "",
        });
        setError(null);
      } catch (err) {
        console.error("Failed to fetch user data:", err);
        setError(err.message);
        // Optionally redirect to login if user is not authenticated
        if (err.message.includes("401") || err.message.includes("403")) {
          navigate("/");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const handleLogout = async () => {
    try {
      await fetch("http://localhost:8000/auth/logout", {
        method: "GET",
        credentials: "include",
      });
      setUserData(null);
      navigate("/");
    } catch (err) {
      console.error("Logout failed:", err);
      // Still navigate to login even if logout request fails
      navigate("/");
    }
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setProfileLoading(true);
    setProfileError(null);
    setProfileSuccess(false);

    try {
      const response = await fetch("http://localhost:8000/users/me", {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(profileForm),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const updatedData = await response.json();
      setUserData(updatedData);
      setProfileSuccess(true);
      
      // Close modal after 2 seconds of success
      setTimeout(() => {
        setShowProfileModal(false);
        setProfileSuccess(false);
      }, 2000);
    } catch (err) {
      console.error("Failed to update profile:", err);
      setProfileError(err.message);
    } finally {
      setProfileLoading(false);
    }
  };

  const openProfileModal = () => {
    setShowMenu(false);
    setShowProfileModal(true);
    setProfileError(null);
    setProfileSuccess(false);
    // Reset form to current user data
    setProfileForm({
      username: userData?.username || "",
      email: userData?.email || "",
    });
  };

  const closeProfileModal = () => {
    setShowProfileModal(false);
    setProfileError(null);
    setProfileSuccess(false);
  };

  const defaultMenuItems = [
    {
      label: "Home",
      icon: BookOpen,
      onClick: () => navigate("/home"),
    },
    {
      label: "My Takes",
      icon: Award,
      onClick: () => navigate("/my-takes"),
    },
    {
      label: "My Tests",
      icon: FileText,
      onClick: () => navigate("/my-tests"),
    },
    {
      label: "Profile Settings",
      icon: Settings,
      onClick: openProfileModal,
    },
    {
      label: "Log Out",
      icon: LogOut,
      onClick: handleLogout,
    },
  ];

  const finalMenuItems = menuItems.length > 0 ? menuItems : defaultMenuItems;

  // Show loading state while fetching user data
  if (loading) {
    return (
      <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              {showBackButton && (
                <button
                  onClick={() => navigate(backButtonPath)}
                  className="w-10 h-10 bg-white/70 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 border border-white/30 hover:bg-white/90"
                >
                  <ArrowLeft className="w-5 h-5 text-gray-700" />
                </button>
              )}
              {Icon && (
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Icon className="w-6 h-6 text-white" />
                </div>
              )}
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {title}
              </h1>
            </div>

            <div className="flex items-center space-x-2 bg-white/70 backdrop-blur-sm rounded-xl px-4 py-2 border border-white/30 shadow-lg">
              <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
              <span className="text-gray-500 text-sm">Loading user...</span>
            </div>
          </div>
        </div>
      </header>
    );
  }

  // Show error state if user data fetch failed
  if (error && !userData) {
    return (
      <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              {showBackButton && (
                <button
                  onClick={() => navigate(backButtonPath)}
                  className="w-10 h-10 bg-white/70 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 border border-white/30 hover:bg-white/90"
                >
                  <ArrowLeft className="w-5 h-5 text-gray-700" />
                </button>
              )}
              {Icon && (
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Icon className="w-6 h-6 text-white" />
                </div>
              )}
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {title}
              </h1>
            </div>

            <div className="flex items-center space-x-2 bg-red-50 border border-red-200 rounded-xl px-4 py-2">
              <span className="text-red-600 text-sm">Failed to load user</span>
              <button
                onClick={() => window.location.reload()}
                className="text-red-600 hover:text-red-800 text-xs underline"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      </header>
    );
  }

  return (
    <>
      <header className="relative bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              {showBackButton && (
                <button
                  onClick={() => navigate(backButtonPath)}
                  className="w-10 h-10 bg-white/70 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 border border-white/30 hover:bg-white/90"
                >
                  <ArrowLeft className="w-5 h-5 text-gray-700" />
                </button>
              )}
              {Icon && (
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Icon className="w-6 h-6 text-white" />
                </div>
              )}
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {title}
              </h1>
            </div>

            {userData && (
              <div className="relative">
                <button
                  onClick={() => setShowMenu(!showMenu)}
                  className="flex items-center space-x-3 bg-white/70 backdrop-blur-sm rounded-xl px-4 py-2 hover:bg-white/90 transition-all duration-300 border border-white/30 shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  <div className="text-right">
                    <div className="text-gray-700 font-medium">
                      {userData.username}
                    </div>
                    <div className="text-gray-500 text-xs">{userData.email}</div>
                  </div>
                  <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                </button>

                {showMenu && (
                  <div className="absolute right-0 mt-2 w-48 rounded-xl shadow-2xl bg-white backdrop-blur-md border border-gray-200 overflow-hidden z-50">
                    {finalMenuItems.map((item, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          item.onClick();
                          setShowMenu(false);
                        }}
                        className="flex items-center space-x-2 w-full text-left px-4 py-3 text-sm text-gray-700 bg-white hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200 border-b border-gray-100 last:border-b-0 focus:outline-none focus:bg-gray-50"
                      >
                        <item.icon className="w-4 h-4" />
                        <span className="font-medium">{item.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Profile Settings Modal */}
      {showProfileModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-auto border border-gray-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                  <Settings className="w-4 h-4 text-white" />
                </div>
                <h2 className="text-xl font-bold text-gray-800">Profile Settings</h2>
              </div>
              <button
                onClick={closeProfileModal}
                className="w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4 text-gray-600" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleProfileUpdate} className="p-6 space-y-4">
              {/* Username Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <UserCircle className="w-4 h-4 inline mr-2" />
                  Username
                </label>
                <input
                  type="text"
                  value={profileForm.username}
                  onChange={(e) => setProfileForm({ ...profileForm, username: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                  placeholder="Enter your username"
                  required
                />
              </div>

              {/* Email Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Mail className="w-4 h-4 inline mr-2" />
                  Email
                </label>
                <input
                  type="email"
                  value={profileForm.email}
                  onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                  placeholder="Enter your email"
                  required
                />
              </div>

              {/* Error Message */}
              {profileError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-red-600 text-sm">{profileError}</p>
                </div>
              )}

              {/* Success Message */}
              {profileSuccess && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-green-600 text-sm">Profile updated successfully!</p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={closeProfileModal}
                  className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors font-medium"
                  disabled={profileLoading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={profileLoading || profileSuccess}
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {profileLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

export default Navbar;