const API_BASE_URL = "http://localhost:8000";

export const testService = {
  async getTests(page = 1, pageSize = 10, tags = [], userId = null) {
    const params = new URLSearchParams({
      page,
      page_size: pageSize,
      ...(tags.length && { tags: tags.join(",") }),
      ...(userId && { user_id: userId }),
    });

    const response = await fetch(`${API_BASE_URL}/tests?${params}`, {
      method: "GET",
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch tests");
    return response.json();
  },

  async getUserTests(page = 1, pageSize = 10, tags = [], userId = null) {
    const params = new URLSearchParams({
      page,
      page_size: pageSize,
      ...(tags.length && { tags: tags.join(",") }),
      ...(userId && { user_id: userId }),
    });

    const response = await fetch(`${API_BASE_URL}/users/my-tests?${params}`, {
      method: "GET",
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch tests");
    return response.json();
  },

  async getUserTakeDetails(takeId) {
    const response = await fetch(`${API_BASE_URL}/users/my-takes/${takeId}`, {
      method: "GET",
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch test info");
    return response.json();
  },

  async deleteTest(testId) {
    const response = await fetch(`${API_BASE_URL}/tests/delete/${testId}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error("Failed to delete test");
    }
  },

  async deleteTestQuestion(testId, questionId) {
    const response = await fetch(
      `${API_BASE_URL}/tests/delete/${testId}/${questionId}`,
      {
        method: "DELETE",
        credentials: "include",
      }
    );

    if (!response.ok) {
      throw new Error("Failed to delete question");
    }
  },

  async getTestInfo(testId) {
    const response = await fetch(`${API_BASE_URL}/tests/${testId}`, {
      method: "GET",
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch test info");
    return response.json();
  },

  async getUserTakes() {
    const response = await fetch(`${API_BASE_URL}/users/my-takes`, {
      method: "GET",
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch test info");
    return response.json();
  },

  async endTest(testId) {
    const response = await fetch(
      `${API_BASE_URL}/tests/finish-test/${testId}`,
      {
        method: "GET",
        credentials: "include",
      }
    );
    if (!response.ok) throw new Error("Failed to finish test");
    return response.json();
  },

  async getTestInfoForEdit(testId) {
    const response = await fetch(`${API_BASE_URL}/tests/tests/edit/${testId}`, {
      method: "GET",
      credentials: "include",
    });
    if (!response.ok) throw new Error("Failed to fetch test info for edit");
    return response.json();
  },

  async editTest(testId, data) {
    const response = await fetch(`${API_BASE_URL}/tests/edit/${testId}`, {
      method: "PUT",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Failed to update test");
    return response.json();
  },

  async editTestQuestion(testId, questionId, data) {
    const response = await fetch(
      `${API_BASE_URL}/tests/edit-question/${testId}/${questionId}`,
      {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      }
    );
    if (!response.ok) throw new Error("Failed to update question");
    return response.json();
  },

  async submitAnswer(testId, questionId, answers) {
    const response = await fetch(
      `${API_BASE_URL}/tests/${testId}/submit-answer/${questionId}`,
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ answers }),
      }
    );
    if (!response.ok) throw new Error("Failed to submit answer");
    return response.json();
  },

  async startTest(testId) {
    const response = await fetch(`${API_BASE_URL}/tests/start-test/${testId}`, {
      method: "GET",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });
    if (!response.ok) throw new Error("Failed to start test");
    return response.json();
  },

  async getTestQuestionsAmount(testId) {
    const response = await fetch(
      `${API_BASE_URL}/tests/${testId}/questions-amount`,
      {
        method: "GET",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    if (!response.ok) throw new Error("Failed to start test");
    return response.json();
  },

  async addTestQuestion(testId, questionData) {
    try {
      const response = await fetch(
        `${API_BASE_URL}/tests/create-qestion/${testId}`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(questionData),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to add question");
      }

      return await response.json();
    } catch (error) {
      console.error("Error adding question:", error);
      // Return mock data in development
      if (process.env.NODE_ENV === "development") {
        const mockQuestion = {
          id: Math.random().toString(36).substr(2, 9),
          ...questionData,
        };
        MOCK_TEST_DETAILS.questions.push(mockQuestion);
        return mockQuestion;
      }
      throw error;
    }
  },
};
