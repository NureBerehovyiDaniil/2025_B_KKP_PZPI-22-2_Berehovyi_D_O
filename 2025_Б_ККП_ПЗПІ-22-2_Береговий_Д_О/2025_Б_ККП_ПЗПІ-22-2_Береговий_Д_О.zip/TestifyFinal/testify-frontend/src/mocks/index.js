// Mock user data
export const MOCK_USER = {
  id: 1,
  username: 'johndoe',
  email: 'john.doe@example.com',
  name: 'John Doe',
  role: 'user'
};

// Mock tests list
export const MOCK_TESTS = [
  {
    id: 1,
    title: 'JavaScript Fundamentals',
    description: 'Test your knowledge of JavaScript basics including variables, functions, and control flow.',
    tags: ['javascript', 'basics', 'programming'],
    question_amount: 15,
    created_at: '2024-03-08T10:00:00Z',
    updated_at: '2024-03-08T10:00:00Z'
  },
  {
    id: 2,
    title: 'React Components',
    description: 'Advanced test covering React components, hooks, and state management.',
    tags: ['react', 'frontend', 'advanced'],
    question_amount: 20,
    created_at: '2024-03-07T15:30:00Z',
    updated_at: '2024-03-07T15:30:00Z'
  },
  {
    id: 3,
    title: 'CSS and Styling',
    description: 'Comprehensive test on CSS layouts, flexbox, grid, and responsive design.',
    tags: ['css', 'frontend', 'design'],
    question_amount: 25,
    created_at: '2024-03-06T09:15:00Z',
    updated_at: '2024-03-06T09:15:00Z'
  },
  {
    id: 4,
    title: 'Backend Development',
    description: 'Test covering Node.js, Express, and database concepts.',
    tags: ['backend', 'nodejs', 'database'],
    question_amount: 30,
    created_at: '2024-03-05T14:45:00Z',
    updated_at: '2024-03-05T14:45:00Z'
  }
];

// Mock test details (for editing)
export const MOCK_TEST_DETAILS = {
  id: 1,
  title: 'JavaScript Fundamentals',
  description: 'Test your knowledge of JavaScript basics including variables, functions, and control flow.',
  tags: ['javascript', 'basics', 'programming'],
  question_amount: 15,
  questions: [
    {
      id: 1,
      question: 'What is the output of console.log(typeof null)?',
      options: ['object', 'null', 'undefined', 'number'],
      correct_answer: 'object',
      tags: ['javascript', 'basics'],
      explanation: 'In JavaScript, typeof null returns "object", which is a known historical bug.'
    },
    {
      id: 2,
      question: 'Which method is used to add elements to the end of an array?',
      options: ['push()', 'pop()', 'shift()', 'unshift()'],
      correct_answer: 'push()',
      tags: ['javascript', 'arrays'],
      explanation: 'The push() method adds one or more elements to the end of an array.'
    },
    {
      id: 3,
      question: 'What is closure in JavaScript?',
      options: [
        'A function that has access to variables in its outer scope',
        'A method to close browser window',
        'A way to end a loop',
        'A type of error handling'
      ],
      correct_answer: 'A function that has access to variables in its outer scope',
      tags: ['javascript', 'advanced'],
      explanation: 'A closure is a function that has access to variables in its outer (enclosing) lexical scope.'
    }
  ],
  created_at: '2024-03-08T10:00:00Z',
  updated_at: '2024-03-08T10:00:00Z'
};

// Mock test session (for test taking)
export const MOCK_TEST_SESSION = {
  id: 1,
  test_id: 1,
  user_id: 1,
  current_question: 1,
  questions: [
    {
      id: 1,
      question: 'What is the output of console.log(typeof null)?',
      options: ['object', 'null', 'undefined', 'number'],
      submitted_answer: null
    },
    {
      id: 2,
      question: 'Which method is used to add elements to the end of an array?',
      options: ['push()', 'pop()', 'shift()', 'unshift()'],
      submitted_answer: null
    },
    {
      id: 3,
      question: 'What is closure in JavaScript?',
      options: [
        'A function that has access to variables in its outer scope',
        'A method to close browser window',
        'A way to end a loop',
        'A type of error handling'
      ],
      submitted_answer: null
    }
  ],
  started_at: '2024-03-09T14:30:00Z',
  completed_at: null
};

// Mock test results
export const MOCK_TEST_RESULTS = {
  id: 1,
  test_id: 1,
  user_id: 1,
  score: 85,
  total_questions: 15,
  correct_answers: 13,
  incorrect_answers: 2,
  skipped_questions: 0,
  time_taken: '25:30', // in minutes:seconds
  completed_at: '2024-03-09T15:00:00Z',
  question_breakdown: [
    {
      question_id: 1,
      question: 'What is the output of console.log(typeof null)?',
      correct_answer: 'object',
      user_answer: 'object',
      is_correct: true,
      time_taken: 45 // seconds
    },
    {
      question_id: 2,
      question: 'Which method is used to add elements to the end of an array?',
      correct_answer: 'push()',
      user_answer: 'push()',
      is_correct: true,
      time_taken: 30
    },
    {
      question_id: 3,
      question: 'What is closure in JavaScript?',
      correct_answer: 'A function that has access to variables in its outer scope',
      user_answer: 'A way to end a loop',
      is_correct: false,
      time_taken: 60
    }
  ]
}; 