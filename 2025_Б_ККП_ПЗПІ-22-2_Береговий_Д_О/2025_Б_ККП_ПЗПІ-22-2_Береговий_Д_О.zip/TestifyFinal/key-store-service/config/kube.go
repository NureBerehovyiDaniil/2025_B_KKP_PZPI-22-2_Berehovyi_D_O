package config

import (
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
)

// GetClient returns a Kubernetes client using in-cluster configuration
func GetClient() (*kubernetes.Clientset, error) {
	config, err := rest.InClusterConfig()
	if err != nil {
		return nil, err
	}

	return kubernetes.NewForConfig(config)
}
