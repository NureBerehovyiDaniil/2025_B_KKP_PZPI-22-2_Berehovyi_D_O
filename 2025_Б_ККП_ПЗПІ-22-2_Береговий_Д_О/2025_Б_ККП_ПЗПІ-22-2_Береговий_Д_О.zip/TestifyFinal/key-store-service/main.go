package main

import (
	"context"
	"flag"
	"key-store/config"
	"key-store/handler"
	"log"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"
)

func main() {
	port := flag.String("port", "8080", "HTTP server port")
	namespace := flag.String("namespace", "key-storage", "Kubernetes namespace")
	configMapName := flag.String("configmap", "api-keys", "ConfigMap name")
	flag.Parse()

	client, err := config.GetClient()
	if err != nil {
		log.Fatalf("Failed to create Kubernetes client: %v", err)
	}

	lock := &sync.Mutex{}

	handlerOpts := handler.KeyHandlerOptions{
		ClientSet:     client,
		Namespace:     *namespace,
		ConfigMapName: *configMapName,
		Lock:          lock,
	}

	mux := http.NewServeMux()
	mux.Handle("/getkey", handler.NewKeyHandler(handlerOpts))
	mux.Handle("/reset", handler.ResetHandler(client, *namespace, *configMapName))

	server := &http.Server{
		Addr:    ":" + *port,
		Handler: mux,
	}

	go func() {
		log.Printf("Server is running on port %s...", *port)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)

	<-stop
	log.Println("Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		log.Fatalf("Server shutdown failed: %v", err)
	}

	log.Println("Server gracefully stopped.")
}
