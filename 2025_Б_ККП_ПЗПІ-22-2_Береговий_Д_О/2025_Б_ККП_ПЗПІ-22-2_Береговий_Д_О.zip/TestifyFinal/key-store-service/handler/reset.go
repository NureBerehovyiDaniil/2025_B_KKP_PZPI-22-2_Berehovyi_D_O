package handler

import (
	"context"
	"encoding/json"
	"net/http"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
)

// ResetHandler resets all key usage counts in the configmap to 0
func ResetHandler(client kubernetes.Interface, namespace, configMapName string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := context.Background()
		cm, err := client.CoreV1().ConfigMaps(namespace).Get(ctx, configMapName, metav1.GetOptions{})
		if err != nil {
			http.Error(w, "Failed to read configmap", http.StatusInternalServerError)
			return
		}

		for k := range cm.Data {
			cm.Data[k] = "0"
		}

		_, err = client.CoreV1().ConfigMaps(namespace).Update(ctx, cm, metav1.UpdateOptions{})
		if err != nil {
			http.Error(w, "Failed to update configmap", http.StatusInternalServerError)
			return
		}

		_ = json.NewEncoder(w).Encode(map[string]string{"status": "reset"})
	}
}
