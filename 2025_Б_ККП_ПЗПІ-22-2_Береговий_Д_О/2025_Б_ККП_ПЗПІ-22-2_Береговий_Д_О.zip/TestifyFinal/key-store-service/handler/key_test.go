package handler

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes/fake"
)

func TestKeyHandler_Success(t *testing.T) {
	client := fake.NewSimpleClientset(&corev1.ConfigMap{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-configmap",
			Namespace: "test-namespace",
		},
		Data: map[string]string{
			"key1": "2",
			"key2": "5",
			"key3": "1",
		},
	})

	req := httptest.NewRequest(http.MethodGet, "/getkey", nil)
	rr := httptest.NewRecorder()

	lock := &sync.Mutex{}
	handler := NewKeyHandler(KeyHandlerOptions{
		ClientSet:     client,
		Namespace:     "test-namespace",
		ConfigMapName: "test-configmap",
		Lock:          lock,
	})

	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusOK {
		t.Fatalf("expected status 200, got %d", rr.Code)
	}

	var resp map[string]string
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("invalid JSON response: %v", err)
	}

	chosenKey := resp["key"]
	if chosenKey != "key3" {
		t.Errorf("expected key3 to be returned, got %s", chosenKey)
	}

	updated, err := client.CoreV1().ConfigMaps("test-namespace").Get(context.Background(), "test-configmap", metav1.GetOptions{})
	if err != nil {
		t.Fatalf("failed to fetch updated configmap: %v", err)
	}

	countStr := updated.Data["key3"]
	count, err := strconv.Atoi(countStr)
	if err != nil {
		t.Fatalf("invalid count in configmap: %v", err)
	}
	if count != 2 {
		t.Errorf("expected updated count for key3 to be 2, got %d", count)
	}
}

func TestKeyHandler_ConfigMapNotFound(t *testing.T) {
	client := fake.NewSimpleClientset()

	req := httptest.NewRequest(http.MethodGet, "/getkey", nil)
	rr := httptest.NewRecorder()

	lock := &sync.Mutex{}
	handler := NewKeyHandler(KeyHandlerOptions{
		ClientSet:     client,
		Namespace:     "test-namespace",
		ConfigMapName: "missing-configmap",
		Lock:          lock,
	})

	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500 status when configmap is missing, got %d", rr.Code)
	}

	if !strings.Contains(rr.Body.String(), "Failed to read configmap") {
		t.Errorf("expected error about missing configmap, got: %s", rr.Body.String())
	}
}

func TestKeyHandler_AllInvalidValues(t *testing.T) {
	client := fake.NewSimpleClientset(&corev1.ConfigMap{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "invalid-configmap",
			Namespace: "test-namespace",
		},
		Data: map[string]string{
			"key1": "NaN",
			"key2": "abc",
			"key3": "-",
		},
	})

	req := httptest.NewRequest(http.MethodGet, "/getkey", nil)
	rr := httptest.NewRecorder()

	lock := &sync.Mutex{}
	handler := NewKeyHandler(KeyHandlerOptions{
		ClientSet:     client,
		Namespace:     "test-namespace",
		ConfigMapName: "invalid-configmap",
		Lock:          lock,
	})

	handler.ServeHTTP(rr, req)

	if rr.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500 status when all keys are invalid, got %d", rr.Code)
	}

	if !strings.Contains(rr.Body.String(), "No valid keys") {
		t.Errorf("expected error 'No valid keys', got: %s", rr.Body.String())
	}
}
