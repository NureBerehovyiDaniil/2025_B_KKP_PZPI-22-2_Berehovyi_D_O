from typing import List, Optional
from sqlalchemy.orm import Session
from ..database import models
import random
from datetime import datetime

class TestService:
    def __init__(self, db: Session):
        self.db = db

    def get_user_performance_stats(self, user_id: int) -> dict:
        """Calculate user performance statistics for different tags and difficulty levels."""
        performances = self.db.query(models.UserQuestionPerformance).filter(
            models.UserQuestionPerformance.user_id == user_id
        ).all()

        stats = {
            'tag_performance': {},
            'difficulty_performance': {i: {'correct': 0, 'total': 0} for i in range(1, 6)}
        }

        for perf in performances:
            question = perf.question
            # Update tag statistics
            for tag in question.tags:
                if tag.name not in stats['tag_performance']:
                    stats['tag_performance'][tag.name] = {'correct': 0, 'total': 0}
                stats['tag_performance'][tag.name]['total'] += 1
                if perf.is_correct:
                    stats['tag_performance'][tag.name]['correct'] += 1

            # Update difficulty statistics
            diff = question.difficulty_level
            stats['difficulty_performance'][diff]['total'] += 1
            if perf.is_correct:
                stats['difficulty_performance'][diff]['correct'] += 1

        return stats

    def select_next_question(self, user_id: int, current_test_id: int, answered_questions: List[int]) -> Optional[models.Question]:
        """Intelligently select the next question based on user performance and test context."""
        stats = self.get_user_performance_stats(user_id)
        
        # Get all questions from the current test that haven't been answered
        available_questions = self.db.query(models.Question).join(
            models.TestQuestion
        ).filter(
            models.TestQuestion.test_id == current_test_id,
            ~models.Question.id.in_(answered_questions)
        ).all()

        if not available_questions:
            return None

        # Calculate weights for each question based on user performance
        question_weights = []
        for question in available_questions:
            weight = 1.0
            
            # Adjust weight based on tag performance
            for tag in question.tags:
                if tag.name in stats['tag_performance']:
                    tag_stats = stats['tag_performance'][tag.name]
                    if tag_stats['total'] > 0:
                        success_rate = tag_stats['correct'] / tag_stats['total']
                        # Increase weight for tags with lower success rate
                        weight *= (1.5 - success_rate)

            # Adjust weight based on difficulty performance
            diff = question.difficulty_level
            diff_stats = stats['difficulty_performance'][diff]
            if diff_stats['total'] > 0:
                success_rate = diff_stats['correct'] / diff_stats['total']
                # Increase weight for difficulties with lower success rate
                weight *= (1.5 - success_rate)

            question_weights.append((question, weight))

        # Select question based on weights
        total_weight = sum(weight for _, weight in question_weights)
        if total_weight == 0:
            return random.choice(available_questions)

        r = random.uniform(0, total_weight)
        current_weight = 0
        for question, weight in question_weights:
            current_weight += weight
            if r <= current_weight:
                return question

        return random.choice(available_questions)

    def generate_test(self, 
                     num_questions: int, 
                     tags: List[str], 
                     difficulty_range: tuple = (1, 5),
                     user_id: Optional[int] = None) -> models.Test:
        """Generate a new test based on specified criteria."""
        # Create base query
        query = self.db.query(models.Question).join(
            models.question_tags
        ).join(
            models.Tag
        ).filter(
            models.Tag.name.in_(tags),
            models.Question.difficulty_level.between(difficulty_range[0], difficulty_range[1])
        )

        # If user_id is provided, consider user performance
        if user_id:
            stats = self.get_user_performance_stats(user_id)
            # Filter out questions the user has already answered correctly multiple times
            query = query.filter(
                ~models.Question.id.in_(
                    self.db.query(models.UserQuestionPerformance.question_id)
                    .filter(
                        models.UserQuestionPerformance.user_id == user_id,
                        models.UserQuestionPerformance.is_correct == True,
                        models.UserQuestionPerformance.attempt_count >= 2
                    )
                )
            )

        # Get available questions
        available_questions = query.all()
        
        if len(available_questions) < num_questions:
            raise ValueError(f"Not enough questions available. Found {len(available_questions)}, requested {num_questions}")

        # Create new test
        test = models.Test(
            title=f"Generated Test - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            description=f"Test generated with {num_questions} questions on topics: {', '.join(tags)}",
            is_adaptive=False,
            created_at=datetime.now()
        )
        self.db.add(test)
        self.db.flush()

        # Select questions and create test questions
        selected_questions = random.sample(available_questions, num_questions)
        for i, question in enumerate(selected_questions):
            test_question = models.TestQuestion(
                test_id=test.id,
                question_id=question.id,
                order=i + 1
            )
            self.db.add(test_question)

        self.db.commit()
        return test 