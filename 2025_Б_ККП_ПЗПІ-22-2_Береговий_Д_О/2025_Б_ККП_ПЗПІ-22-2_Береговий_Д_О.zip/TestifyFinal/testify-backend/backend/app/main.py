from fastapi import FastAPI
from app.api.auth.resource import auth_router
from app.api.tests.resource import router as test_router
from app.api.users.resource import user_router
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(
    title="Testify",
    description="Testify is a test management system that helps you manage your tests and their results.",
    version="0.1.0",

)

@app.on_event("startup")
async def print_envs():
    print("=== Environment Variables ===")
    for k, v in os.environ.items():
        print(f"{k}={v}")
    print("=============================")

app.include_router(auth_router)
app.include_router(test_router)
app.include_router(user_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # або вкажи конкретно ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
