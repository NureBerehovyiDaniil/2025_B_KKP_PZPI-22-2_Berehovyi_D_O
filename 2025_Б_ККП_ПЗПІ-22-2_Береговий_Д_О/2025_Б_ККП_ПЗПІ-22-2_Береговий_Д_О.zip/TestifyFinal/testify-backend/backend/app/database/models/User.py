import uuid

from datetime import datetime

from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy import Column, String, Integer, Boolean, DateTime, UUID, ForeignKey


from ..base_model import Base

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, index=True)
    username = Column(String(50), unique=True, index=True)
    email = Column(String(100), unique=True, index=True)
    password = Column(String(100))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow) 
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)  
    

class UserTests(Base):
    __tablename__ = "user_tests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, index=True)
    owner_id = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    test_id = Column(String())

    def __repr__(self):
        return f"<UserTests(user_id={self.user_id}>"


class UserTakes(Base):
    __tablename__ = "user_takes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), index=True)
    test_id = Column(String(), index=True)
    completed_at = Column(DateTime)

    def __repr__(self):
        return f"<UserTakesTest(user_id={self.user_id})>"
    
    
class UserAnswers(Base):
    __tablename__ = "user_answers"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, index=True)
    user_take_id = Column(UUID(as_uuid=True), ForeignKey('user_takes.id'), index=True)
    question_id = Column(String(), index=True)
    answers_ids = Column(ARRAY(String()), nullable=True)  # Assuming multiple answers can be selected

    def __repr__(self):
        return f"<UserAnswers(user_take_id={self.user_take_id})>"
    
    
class TestDetails(Base):
    __tablename__ = "test_details"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, index=True)
    test_id = Column(String(), index=True)
    title = Column(String(100), index=True)
    description = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<TestDetails(test_id={self.test_id}, title={self.title})>"
