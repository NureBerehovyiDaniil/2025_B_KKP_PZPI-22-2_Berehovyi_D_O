from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
import uuid
class UserResponseSchema(BaseModel):
    email: str = Field(..., description="Email address of the user")
    username: str = Field(..., description="Username of the user")


class UserTakesResponseSchema(BaseModel):
    id: uuid.UUID = Field(..., description="Unique identifier for the user take")
    test_id: str = Field(..., description="Unique identifier for the test taken by the user")
    completed_at: datetime = Field(..., description="Timestamp when the test was completed")
    title: str = Field(..., description="Title of the test")
    description: str = Field(..., description="Description of the test")
    questions_amount: int = Field(..., description="Total number of questions in the test")
    tags: list[str] = Field(default_factory=list, description="List of tags associated with the test")
    res_count: int = Field(..., description="Count of correct answers provided by the user")
    
class UserTakeDetailsResponseSchema(BaseModel):
    id: uuid.UUID = Field(..., description="Unique identifier for the user take")
    test_id: str = Field(..., description="Unique identifier for the test taken by the user")
    completed_at: datetime = Field(..., description="Timestamp when the test was completed")
    title: str = Field(..., description="Title of the test")
    description: str = Field(..., description="Description of the test")
    questions_amount: int = Field(..., description="Total number of questions in the test")
    tags: list[str] = Field(default_factory=list, description="List of tags associated with the test")
    res_count: int = Field(..., description="Count of correct answers provided by the user")
    questions: List[dict] = Field(default_factory=list, description="List of questions with user's answers")
    
    
    
class UserTestsResponse(BaseModel):
    test_id: str
    title: str
    description: str
    question_amount: int
    tags: List[str] = Field(default_factory=list, description="List of tags associated with the test")
    