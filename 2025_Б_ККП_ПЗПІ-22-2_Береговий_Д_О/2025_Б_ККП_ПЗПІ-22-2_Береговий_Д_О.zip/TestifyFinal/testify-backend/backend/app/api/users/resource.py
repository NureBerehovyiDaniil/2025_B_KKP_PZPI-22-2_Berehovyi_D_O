from typing import Annotated, List
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer

from sqlalchemy.future import select

from app.database.conn import get_db
from app.database.models.User import User

from app.utils.queries.fetching import fetch_one_or_none

from app.utils.auth.authentication import Authorization

from .service import UserService
from .schema import UserResponseSchema, UserTakesResponseSchema, UserTestsResponse

user_router = APIRouter(
    prefix="/users",
    tags=["users"],
)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")


@user_router.get("/auth-token-schema")
async def get_oauth2_scheme_schema(token: str = Depends(oauth2_scheme)):
    """
    Returns the OAuth2PasswordBearer schema.
    This is useful for documentation purposes.
    """
    return oauth2_scheme
    

@user_router.get("/me", response_model=UserResponseSchema)
async def get_user( user: Annotated[dict, Depends(Authorization())]):
    return user


@user_router.put("/me", response_model=UserResponseSchema)
async def get_user(body: UserResponseSchema, user: Annotated[dict, Depends(Authorization())], db = Depends(get_db)):
    user.email = body.email
    user.username = body.username
    await db.commit()
    return user


@user_router.get("/my-takes", response_model=List[UserTakesResponseSchema])
async def get_user_takes(user: Annotated[dict, Depends(Authorization())], db = Depends(get_db)):
    user_service = UserService(db)
    user_takes = await user_service.get_user_takes(user["id"])
    return user_takes


@user_router.get("/my-takes/{take_id}")
async def get_user_take(
    take_id: str,
    user: Annotated[dict, Depends(Authorization())],
    db = Depends(get_db)
):
    user_service = UserService(db)
    user_take_details = await user_service.get_user_take(take_id, user["id"])
    
    if not user_take_details:
        raise HTTPException(status_code=404, detail="Take not found")
    
    return user_take_details


@user_router.get("/my-tests", response_model=List[UserTestsResponse])
async def get_user_tests(
    user: Annotated[dict, Depends(Authorization())],
    db = Depends(get_db)
):
    user_service = UserService(db)
    user_tests = await user_service.get_user_tests(user.id)
    return user_tests