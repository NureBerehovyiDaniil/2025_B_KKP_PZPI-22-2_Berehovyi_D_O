from sqlalchemy import select
from app.database.models import *
from app.api._shared.http_client import HttpClient


class UserService:
	def __init__(self, db):
		self.db = db


	async def get_user_takes(self, user_id):
		query = (
			select(UserTakes, TestDetails)
			.join(TestDetails, TestDetails.test_id == UserTakes.test_id)
			.where(
				UserTakes.user_id == user_id,
				UserTakes.completed_at.isnot(None)
			)
		)
		result = await self.db.execute(query)
		rows = result.all()
		res = []
		for take, details in rows:
			test_questions = HttpClient.get_request("questions/by-test", {"test_id": take.test_id})
			if not test_questions:
				raise ValueError("Test questions not found")
			res.append({
				"id": take.id,
				"test_id": take.test_id,
				"completed_at": take.completed_at,
				"title": details.title,
				"description": details.description,
				"questions_amount": len(test_questions),
				"tags": await self._collecttags_from_list_of_questions(test_questions),
				"res_count": await self.__get_test_result(take.id, take.test_id)
			})
		return res


	async def get_user_take(self, take_id, user_id):
		take_query = (
			select(UserTakes, TestDetails)
			.join(TestDetails, TestDetails.test_id == UserTakes.test_id)
			.where(UserTakes.id == take_id, UserTakes.user_id == user_id)
		)
		take_result = await self.db.execute(take_query)
		take_row = take_result.one_or_none()

		if not take_row:
			return None

		take, details = take_row

		answers_query = (
			select(UserAnswers)
			.where(UserAnswers.user_take_id == take.id)
		)
		answers_result = await self.db.execute(answers_query)
		user_answers = answers_result.scalars().all()

		test_questions = HttpClient.get_request("questions/by-test", {"test_id": take.test_id})
		if not test_questions:
			raise ValueError("Test questions not found")

		test_question_answers = []
		for test_question in test_questions:
			matched = False
			for user_answer in user_answers:
				if user_answer.question_id == test_question["id"]:
					t = test_question.copy()
					t["selected_answers"] = user_answer.answers_ids
					test_question_answers.append(t)
					matched = True
					break  
			if not matched:
				t = test_question.copy()
				t["selected_answers"] = []
				test_question_answers.append(t)
		
		return {
			"id": take.id,
			"test_id": take.test_id,
			"completed_at": take.completed_at,
			"title": details.title,
			"description": details.description,
			"questions_amount": len(test_questions),
			"tags": await self._collecttags_from_list_of_questions(test_questions),
			"res_count": await self.__get_test_result(take.id, take.test_id),
			"questions": test_question_answers
		}


	async def get_user_tests(self, user_id):
		"""Retrieve a list of tests available for the user."""
		user_tests_ids_query = select(UserTests.test_id).where(UserTests.owner_id == user_id)
		user_tests_ids_exec = await self.db.execute(user_tests_ids_query)
		user_tests_ids = user_tests_ids_exec.scalars().all()

		if not user_tests_ids:
			return []
  
		test_query = select(TestDetails).where(TestDetails.test_id.in_(user_tests_ids))
		test_exec = await self.db.execute(test_query)
		tests = test_exec.scalars().all()
  
		res = []
		for test in tests:
			test_questions = HttpClient.get_request("questions/by-test", {"test_id": test.test_id})
			test_dict = dict(test)
			test_dict["tags"] = await self._collecttags_from_list_of_questions(test_questions)
			test_dict["question_amount"] = len(test_questions)
			res.append(test_dict)
		# замапить количество вопросов
		return res


	async def __get_test_result(self, test_take_id, test_id):
		query = (
			select(UserAnswers)
			.where(
				UserAnswers.user_take_id == test_take_id,
			)
		)
		answers_res = await self.db.execute(query)
		answers = answers_res.scalars().all()
		count = 0
		for answer in answers:

			correct_option = HttpClient.get_request("question/correct-option", {"test_id": test_id, "question_id": answer.question_id})
			if not correct_option:
				raise ValueError("Question not found")

			if list(correct_option.get("option_id", [])) == answer.answers_ids:
				count += 1
		return count


	async def _collecttags_from_list_of_questions(self, questions):
		"""Collect unique tags from a list of questions."""
		tags = set()
		for question in questions:
			if "tags" in question:
				tags.update(question["tags"])
		return list(tags)