from requests import request
from app.core.settings import settings

class HttpClient:
    DB_GATEWAY_URL = settings.DB_GATEWAY_URL
    
    
    @classmethod
    def get_request(cls, endpoint: str, params: dict = None):
        """
        Make a GET request to the DB Gateway.
        
        :param endpoint: The API endpoint to call.
        :param params: Optional query parameters.
        :return: Response from the request.
        """
        url = f"{cls.DB_GATEWAY_URL}/{endpoint}"
        print(f"\033[91mAAAAAAAAAAAAAAAAAAAAAAAAAAA\033[0m")

        print(f"\033[91m{url}\033[0m")
        response = request("GET", url, params=params)
        response.raise_for_status()

        return response.json()
    
    @classmethod
    def post_request(cls, endpoint: str, data: dict = None):
        """
        Make a POST request to the DB Gateway.
        
        :param endpoint: The API endpoint to call.
        :param data: Optional data to send in the request body.
        :return: Response from the request.
        """
        url = f"{cls.DB_GATEWAY_URL}/{endpoint}"
        response = request("POST", url, json=data)
        response.raise_for_status()
        
        return response.json() if response.content else None
    
    @classmethod
    def put_request(cls, endpoint: str, data: dict = None):
        """
        Make a PUT request to the DB Gateway.
        
        :param endpoint: The API endpoint to call.
        :param data: Optional data to send in the request body.
        :return: Response from the request.
        """
        url = f"{cls.DB_GATEWAY_URL}/{endpoint}"
        response = request("PUT", url, json=data)
        response.raise_for_status()
        
        return response.json() if response.content else None
    
    @classmethod
    def delete_request(cls, endpoint: str, query_params: dict = None):
        """
        Make a DELETE request to the DB Gateway.
        
        :param endpoint: The API endpoint to call.
        :return: Response from the request.
        """
        url = f"{cls.DB_GATEWAY_URL}/{endpoint}"
        response = request("DELETE", url, params=query_params)
        response.raise_for_status()
        
        return response.json() if response.content else None