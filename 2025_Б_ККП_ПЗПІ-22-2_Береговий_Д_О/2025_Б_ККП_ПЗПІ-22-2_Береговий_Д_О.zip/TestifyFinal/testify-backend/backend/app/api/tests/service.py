from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.conn import get_db
from pydantic import BaseModel
from datetime import datetime
from .schema import TestGenerationRequest, TestResponse
from app.api._shared.http_client import HttpClient
import random
from app.database.models import *
from sqlalchemy import select, exists


class TestService():
	def __init__(self, db):
		self.db = db
	
	async def get_test_info(self, test_id: int):
		"""Retrieve test information by ID."""
		is_test_exists = HttpClient.get_request(f"test/exists", {"test_id": test_id})
		if not is_test_exists:
			raise ValueError("Test not found")
		
		test_info = select(TestDetails).where(TestDetails.test_id == test_id)
		test_info_exec = await self.db.execute(test_info)
		test_info = test_info_exec.scalars().first()
  
		test_questions = HttpClient.get_request("questions/by-test", {"test_id": test_id})
		if not test_questions:
			raise ValueError("Test questions not found")
		
		response_data = {
			"id": test_info["test_id"],
			"title": test_info["title"],
			"description": test_info.get("description", ""),
			"question_amount": len(test_questions),
			"tags": await self._collecttags_from_list_of_questions(test_questions),
		}
		
		return response_data
	
 
	async def edit_test_question(self, data: dict, user_id, test_id) -> dict:
		self.__check_is_user_test_owner(user_id, test_id)

		"""Edit a question in a test."""
		if not data.get("question"):
			raise ValueError("Question content is required")
		
		response = HttpClient.post_request(f"question/edit", data)
		if not response:
			raise ValueError("Failed to edit question")
		
		return response
 
 
	async def get_test_info_for_edit(self, test_id: str) -> dict:
		"""Retrieve test information for editing."""
		test_info = await self.get_test_info(test_id)
		if not test_info:
			raise ValueError("Test not found")

		test_questions = HttpClient.get_request("questions/by-test", {"test_id": test_id})

		return {
			"id": test_info["id"],
			"title": test_info["title"],
			"description": test_info["description"],
			"question_amount": test_info["question_amount"],
			"tags": test_info["tags"],
			"questions": test_questions
		}
	

	async def edit_question(self, test_id: str, question_id: str, body: dict, user_id) -> dict:
		"""Edit a question in a test."""
		self.__check_is_user_test_owner(user_id, test_id)

		if not body.get("question"):
			raise ValueError("Question content is required")
		
		response = HttpClient.put_request(f"questions/edit/{test_id}/{question_id}", body)
		if not response:
			raise ValueError("Failed to edit question")
		
		return response


	async def edit_test(self, test_id: str, body: dict, user_id: None) -> dict:
		"""Edit test information."""
		self.__check_is_user_test_owner(user_id, test_id)
		if not body.get("title"):
			raise ValueError("Title is required")
		test_data_query = select(TestDetails).where(TestDetails.test_id == test_id)
		test_data_exec = await self.db.execute(test_data_query)
		test_data = test_data_exec.scalars().first()

		if not test_data:
			raise ValueError("Test not found")

		test_data.title = body.get("title", test_data.title)
		test_data.description = body.get("description", test_data.description)
		self.db.add(test_data)
		await self.db.commit()
		await self.db.refresh(test_data)
		return test_data


	async def handle_answer_submission(self, test_id: str, question_id: str, answers: List[str], user_id) -> dict:
		"""Handle the submission of an answer for a question."""
		response = await self.check_answer(test_id, question_id, answers)
		
		
		user_take_query = select(UserTakes).where(
			UserTakes.test_id == test_id,
			UserTakes.user_id == user_id,
			UserTakes.completed_at == None
		)
		user_take_exec = await self.db.execute(user_take_query)
		user_take = user_take_exec.scalars().first()
		
		if not user_take:
			raise ValueError("No active session found for the user and test")
		
		user_answer = UserAnswers(
			user_take_id=user_take.id,
			question_id=question_id,
			answers_ids=answers  # Assuming answers is a list of selected option IDs
		)
		
		self.db.add(user_answer)
		await self.db.commit()
		await self.db.refresh(user_answer)

		return response
  
  
	async def check_answer(self, test_id: str, question_id: str, answers: List[str]) -> dict:
		"""Submit an answer for a question."""
		response = HttpClient.get_request("question/correct-option", {
			"test_id": test_id,
			"question_id": question_id
		})
		if not response:
			raise ValueError("Failed to submit answer")

		if response["option_id"] != answers[0]:
			return False
		return True
	
	
	async def select_next_question(self, question_id: str, test_id: str, user_answers: List[str], user_id) -> Optional[dict]:
		"""Select the next question for an adaptive test based on user answers."""
		current_session_query = select(UserTakes).where(
			UserTakes.test_id == test_id,
			UserTakes.user_id == user_id,
			UserTakes.completed_at == None
		)
		current_session_exec = await self.db.execute(current_session_query)
		current_session = current_session_exec.scalars().first()
		
		if not current_session:
			raise ValueError("No active session found for the user and test")

		existing_answers_query = select(UserAnswers).where(
			UserAnswers.user_take_id == current_session.id,
		)
		answers_exec = await self.db.execute(existing_answers_query)
		existing_answers = answers_exec.scalars().all()
		answered_ids = {a.question_id for a in existing_answers}
  
		all_questions = HttpClient.get_request("questions/by-test", {
			"test_id": test_id
		})
  
		incorrect_tags = []

		# Перевірка правильності відповідей
		for ans in user_answers:
			q = next((q for q in all_questions if q["id"] == ans[0]), None)
			if q:
				selected_option = next((opt for opt in q["options"] if opt.get("id") == ans[0]), None)
				if selected_option and not selected_option.get("correct", False):
					incorrect_tags.extend(q["tags"])

		# Пріоритет — питання за тегами помилок
		prioritized = [
			q for q in all_questions
			if q["id"] not in answered_ids and any(tag in incorrect_tags for tag in q["tags"])
		]

		# Резервний список — усі інші питання
		fallback = [
			q for q in all_questions
			if q["id"] not in answered_ids
		]

		if prioritized:
			return {"next_question": random.choice(prioritized)}
		elif fallback:
			return {"next_question": random.choice(fallback)}
		else:
			current_session.completed_at = datetime.utcnow()
			await self.db.commit()
			return {"next_question": 'No more questions available'}
	

	async def get_tests_list(self, query) -> List[dict]:
		"""Retrieve a list of tests available for the user."""
		test_query = select(TestDetails)
		test_exec = await self.db.execute(test_query)
		tests = test_exec.scalars().all()
		if not tests:
			return []
		res = []
		for test in tests:
			test_questions = HttpClient.get_request("questions/by-test", {"test_id": test.test_id})
			test_dict = dict(test)
			test_dict["tags"] = await self._collecttags_from_list_of_questions(test_questions) if test_questions else []
			test_dict["question_amount"] = len(test_questions) if test_questions else 0
			res.append(test_dict)
		# замапить количество вопросов
		return res


	async def _collecttags_from_list_of_questions(self, questions: List[dict]) -> List[str]:
		"""Collect unique tags from a list of questions."""
		tags = set()
		if not questions:
			return []
		for question in questions:
			if "tags" in question:
				tags.update(question["tags"])
		return list(tags)


	async def start_test(self, test_id: str, user_id) -> dict:
		"""Start a new test session for the user."""
		test_exists = HttpClient.get_request("test/exists", {"test_id": test_id})
		if not test_exists:
			raise ValueError("Test not found")
		
		user_take = UserTakes(
			user_id=user_id,
			test_id=test_id,
			completed_at=None
		)
		
		self.db.add(user_take)
		await self.db.commit()
		await self.db.refresh(user_take)
		
		test_questions = HttpClient.get_request("questions/by-test", {"test_id": test_id})
		first_question = test_questions[0] if test_questions else None
		# return {
		# 	"message": "Test started successfully",
		# 	"user_take_id": user_take.id
		# }
		return first_question if first_question else {"message": "No questions available for this test"}


	async def get_questions_amount(self, test_id: str) -> int:
		"""Get the total number of questions in a test."""
		test_exists = HttpClient.get_request("test/exists", {"test_id": test_id})
		if not test_exists:
			raise ValueError("Test not found")
		
		test_questions = HttpClient.get_request("questions/by-test", {"test_id": test_id})
		if not test_questions:
			raise ValueError("No questions found for this test")
		
		return len(test_questions)

	async def create_test_question(self, data: dict, user_id, test_id) -> dict:
		"""Create a new question for a test."""
		self.__check_is_user_test_owner(user_id, test_id)

		if not data.get("question"):
			raise ValueError("Question content is required")
		
		response = HttpClient.post_request(f"submit-question", data)
		if not response:
			raise ValueError("Failed to create question")
		
		return response


	async def fill_test_details(self, test_id: str, body: dict) -> dict:
		"""Fill in the details of a test."""
		test_exists = HttpClient.get_request("test/exists", {"test_id": test_id})
		if not test_exists:
			raise ValueError("Test not found")
		
		test_details = TestDetails(
			test_id=test_id,
			title=body.get("title", ""),
			description=body.get("description", "")
		)
		
		self.db.add(test_details)
		
		return {
			"id": test_details.test_id,
			"title": test_details.title,
			"description": test_details.description
		}


	async def fill_user_test(self, test_id, user_id):
		"""Associate a test with a user."""
		test_exists = HttpClient.get_request("test/exists", {"test_id": test_id})
		if not test_exists:
			raise ValueError("Test not found")

		stmt = select(exists().where(User.id == user_id))
		result = await self.db.execute(stmt)
		user_exists = result.scalar() 
		if not user_exists:	
			raise ValueError("User not found")

		new_user_test = UserTests(
			owner_id=user_id,
			test_id=test_id
		)
		self.db.add(new_user_test)
  
  
	async def finish_test(self, test_id: str, user_id) -> dict:
		"""Finish a test session for the user."""
		user_take_query = select(UserTakes).where(
			UserTakes.test_id == test_id,
			UserTakes.user_id == user_id,
			UserTakes.completed_at == None
		)
		user_take_exec = await self.db.execute(user_take_query)
		user_take = user_take_exec.scalars().first()
		
		if not user_take:
			raise ValueError("No active session found for the user and test")
		
		user_take.completed_at = datetime.utcnow()
		await self.db.commit()
		
		return "Ok"

	async def __check_is_user_test_owner(self, user_id, test_id):
		user_test_query = select(UserTests).where(UserTests.test_id == test_id, UserTests.owner_id == user_id)
		user_test_exec = await self.db.execute(user_test_query)
		user_test_owner = user_test_exec.scalars().first()
  
		if not user_test_owner:
			raise ValueError("you are now owner")

 
	async def delete_test_question(self, test_id: str, question_id: str, user_id) -> dict:
		"""Delete a question from a test."""
		self.__check_is_user_test_owner(user_id, test_id)

		response = HttpClient.delete_request(f"question/delete-by-id", {"test_id": test_id, "question_id": question_id})
		if not response:
			raise ValueError("Failed to delete question")
		
		return {"message": "Question deleted successfully"}


	async def delete_test(self, test_id: str, user_id) -> dict:
		"""Delete a test."""
		self.__check_is_user_test_owner(user_id, test_id)
		test_data_query = select(TestDetails).where(TestDetails.test_id == test_id)
		test_data_exec = await self.db.execute(test_data_query)
		test_data = test_data_exec.scalars().first()
  
		test_owner_query = select(UserTests).where(UserTests.test_id == test_id)
		test_owner_exec = await self.db.execute(test_owner_query)
		test_owner = test_owner_exec.scalars().first()
  
		if test_data:
			await self.db.delete(test_data)

		if test_owner:
			await self.db.delete(test_owner)

		# Commit the transaction
		await self.db.commit()

		response = HttpClient.delete_request(f"test/delete-by-id/{test_id}", {"test_id": test_id})
		if not response:
			raise ValueError("Failed to delete test")
		
		return {"message": "Test deleted successfully"}