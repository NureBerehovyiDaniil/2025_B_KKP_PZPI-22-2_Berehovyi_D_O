from pydantic import BaseModel, Field
from typing import List



class TestInfoResponse(BaseModel):
    """
    Response schema for test information.
    """
    id: str
    title: str
    description: str
    question_amount: int
    tags: List[str] = Field(default_factory=list, description="List of tags associated with the test")

class TestInfoEditResponse(BaseModel):
    """
    Response schema for test information used in editing.
    """
    id: str
    title: str
    description: str
    question_amount: int
    tags: List[str] = Field(default_factory=list, description="List of tags associated with the test")
    questions: List[dict] = Field(default_factory=list, description="List of questions associated with the test")