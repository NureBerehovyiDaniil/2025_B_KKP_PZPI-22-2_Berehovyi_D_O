from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel, Field
import uuid

class TestGenerationRequest(BaseModel):
    title: str
    description: Optional[str] = None

class TestResponse(BaseModel):
    test_id: str
    title: str
    description: str
    question_amount: int
    tags: List[str] = Field(default_factory=list, description="List of tags associated with the test")
    
    
class TestListQuery(BaseModel):
    user_id: Optional[int] = None
    tags: Optional[List[str]] = None

    page: int = Field(1, ge=1, description="Page number for pagination")
    page_size: int = Field(10, ge=1, le=100, description="Number of items per page")
    
    
class EditTestSchema(BaseModel):
    title: str
    description: Optional[str] = None


class OptionSchema(BaseModel):
    id: Optional[str] = None
    text: str
    correct: Optional[bool] = False

class EditQuestionSchema(BaseModel):
    question: str
    options: List[OptionSchema]
    tags: List[str] = Field(default_factory=list)
    test_id: Optional[str] = None
    question_id: Optional[str] = None

class SubmitAnswerSchema(BaseModel):
    answers: List[str] = Field(..., description="List of answers submitted by the user")
    