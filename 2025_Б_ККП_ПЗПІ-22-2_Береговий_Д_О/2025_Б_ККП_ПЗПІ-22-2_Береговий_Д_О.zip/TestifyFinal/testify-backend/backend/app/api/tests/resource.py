import uuid
from typing import List, Optional, Annotated
from fastapi import APIRouter, Depends, HTTPException, Body, Query, status
from sqlalchemy.orm import Session
from app.database.conn import get_db

from .service import TestService
from .schema import TestGenerationRequest, TestResponse, TestListQuery, EditTestSchema, EditQuestionSchema, SubmitAnswerSchema
from .response_schema import TestInfoResponse, TestInfoEditResponse
from app.utils.auth.authentication import Authorization

router = APIRouter(prefix="/tests", tags=["tests"])

# добавить эндпоинт для бобра для заполнения тест деталей - done
# добавить фильтрі для тестов (по тегам, по сложности, по количеству вопросов и т.д.)
# добавить ресурс для получения инфі по юзеру (какие тесты он прошел, сколько баллов набрал и т.д.) - done
# добавить профиль юзера с возможностью редактирования (изменение пароля, аватарки и т.д.) - done
# чистить куки в логауте - done
# user_test заполнять при генерации для бобра - done
# когда нажимаем выйти тест, то нужно завершать сессию юзера в тесте и сохранять результаты -done
# edit test only if user a creator - done

@router.get("/", response_model=List[TestResponse])
async def get_tests(query: TestListQuery = Query() ,db: Session = Depends(get_db)):
    test_service = TestService(db)
    tests = await test_service.get_tests_list(query)
    return tests


@router.get("/{test_id}", response_model=TestInfoResponse)
async def get_test(test_id: str, db: Session = Depends(get_db)):
    test_service = TestService(db)
    test_info = await test_service.get_test_info(test_id)
    if not test_info:
        raise HTTPException(status_code=404, detail="Test not found")
    return TestInfoResponse(
        id=test_info["id"],
        title=test_info["title"],
        description=test_info["description"],
        question_amount=test_info["question_amount"],
        tags=test_info["tags"] or [],
    )

@router.put("/edit-question/{test_id}/{question_id}")
async def edit_test_question(
    test_id: str,
    question_id: str,
    user: Annotated[dict, Depends(Authorization())],
    body: EditQuestionSchema,
    db: Session = Depends(get_db)
):
    # Створюємо нову модель із доданими полями
    updated_body = body.copy(update={"test_id": test_id, "question_id": question_id})

    test_service = TestService(db)
    await test_service.edit_test_question(updated_body.model_dump(), user.id, test_id)
    return status.HTTP_200_OK, {"message": "Question edited successfully"}


@router.post("/create-qestion/{test_id}")
async def create_test_question(
    test_id: str,
    user: Annotated[dict, Depends(Authorization())],
    body: EditQuestionSchema,
    db: Session = Depends(get_db)
):
    # Створюємо нову модель із доданими полями
    updated_body = body.copy(update={"test_id": test_id})

    test_service = TestService(db)
    await test_service.create_test_question(updated_body.model_dump(), user.id, test_id)
    return status.HTTP_201_CREATED, {"message": "Question created successfully"}


@router.get("/tests/edit/{test_id}", response_model=TestInfoEditResponse)
async def get_test_info_for_edit(test_id: str, db: Session = Depends(get_db)):
    test_service = TestService(db)
    test_info = await test_service.get_test_info_for_edit(test_id)
    if not test_info:
        raise HTTPException(status_code=404, detail="Test not found")
    return TestInfoEditResponse(
        id=test_info["id"],
        title=test_info["title"],
        description=test_info["description"],
        question_amount=test_info["question_amount"],
        tags=test_info["tags"] or [],
        questions=test_info["questions"] or [],
    )


@router.put("/edit/{test_id}")
async def edit_test(test_id: str,  user: Annotated[dict, Depends(Authorization())], body: EditTestSchema = Body(), db: Session = Depends(get_db)):
    test_service = TestService(db)    
    await test_service.edit_test(
        test_id=test_id,
        body=body.model_dump(),
        user_id=user.id
    )
    return status.HTTP_200_OK, {"message": "Test edited successfully"}

@router.get("/start-test/{test_id}")
async def start_test(test_id: str, user: Annotated[dict, Depends(Authorization())], db: Session = Depends(get_db)):
    test_service = TestService(db)
    first_question = await test_service.start_test(test_id, user_id=user.get("id", None))
    return first_question


@router.get("/{test_id}/questions-amount")
async def get_questions_amount(test_id: str, db: Session = Depends(get_db)):
    test_service = TestService(db)
    questions_amount = await test_service.get_questions_amount(test_id)
    return questions_amount


@router.post("/{test_id}/submit-answer/{question_id}")
async def submit_answer(test_id: str, question_id: str, user: Annotated[dict, Depends(Authorization())], body: SubmitAnswerSchema = Body(), db: Session = Depends(get_db)):
    test_service = TestService(db)
    await test_service.handle_answer_submission(
        test_id=test_id,
        question_id=question_id,
        answers=body.answers,
        user_id=user.get("id", None)
    )
    next_question = await test_service.select_next_question(
        question_id=question_id,
        test_id=test_id,
        user_answers=body.answers,
        user_id=user.get("id", None)
    )
    return next_question or {"message": "No more questions available"}


@router.post("/fill-test-details/{test_id}")
async def fill_test_details(test_id: str, user: Annotated[dict, Depends(Authorization())], body: TestGenerationRequest = Body(), db: Session = Depends(get_db)):
    test_service = TestService(db)
    body_dict = body.model_dump()
    
    await test_service.fill_user_test(
        test_id=test_id,
        user_id=user.id
    )
    await test_service.fill_test_details(
        test_id=test_id,
        body=body_dict
    )
    db.commit()
    return status.HTTP_200_OK, {"message": "Test details filled successfully"}


@router.get("/finish-test/{test_id}")
async def finish_test(test_id:str, user: Annotated[dict, Depends(Authorization())], db: Session = Depends(get_db)):
    test_service = TestService(db)
    await test_service.finish_test(test_id, user_id=user.get("id", None))
    return status.HTTP_200_OK, {"message": "Test finished successfully"}


@router.delete("/delete/{test_id}/{question_id}")
async def delete_test_question(test_id:str, question_id: str, user: Annotated[dict, Depends(Authorization())], db: Session = Depends(get_db)):
    test_service = TestService(db)
    await test_service.delete_test_question(test_id, question_id, user.get("id", None))
    return status.HTTP_204_NO_CONTENT


@router.delete("/delete/{test_id}")
async def delete_test(test_id: str, user: Annotated[dict, Depends(Authorization())], db: Session = Depends(get_db)):
    test_service = TestService(db)
    await test_service.delete_test(test_id, user.get("id", None))
    return status.HTTP_204_NO_CONTENT