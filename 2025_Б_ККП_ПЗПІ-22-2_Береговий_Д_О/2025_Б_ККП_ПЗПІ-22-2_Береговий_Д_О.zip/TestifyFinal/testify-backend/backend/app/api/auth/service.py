import uuid
from fastapi import HTTPException, status, Depends, Response
from fastapi.security import OAuth2PasswordRequestForm

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.User import User
from app.database.conn import get_db

from app.utils.encryption.password import hash_password
from app.utils.queries.fetching import fetch_one_or_none
from app.utils.auth.authentication import authenticate_user
from app.utils.auth.token import create_access_token, create_refresh_token, get_user_from_token
from app.utils.auth.constants import ACCESS_TOKEN_EXPIRE_MINUTES, REFRESH_TOKEN_EXPIRE_MINUTES, COOKIE_OPTIONS

from .schema import CreateUser


async def register_user(user: CreateUser, db: AsyncSession):
    print(f"\033[91m{user.email}\033[0m")

    query = select(User).where(User.email == user.email)
    existing_user = await fetch_one_or_none(db, query)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already exists",
        )
    
    hashed_password = hash_password(user.password)
    new_user = User(
        email=user.email,
        username=uuid.uuid4().hex,  # Generate a unique username
        password=hashed_password,
    )
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)

    return {"msg": "User created successfully", "user": new_user}   


async def login_user(form_data: OAuth2PasswordRequestForm, response: Response, db: AsyncSession):
    user = await authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token = await create_access_token(dict(user))
    refresh_token = await create_refresh_token(dict(user))

    response.set_cookie("access_token", access_token, max_age=ACCESS_TOKEN_EXPIRE_MINUTES, **COOKIE_OPTIONS)
    response.set_cookie("refresh_token", refresh_token, max_age=REFRESH_TOKEN_EXPIRE_MINUTES, **COOKIE_OPTIONS)

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }


async def refresh_user_token(response: Response, refresh_token: str, db: AsyncSession):
    if not refresh_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )
    
    user = await get_user_from_token(refresh_token, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )
    
    access_token = await create_access_token(dict(user))
    new_refresh_token = await create_refresh_token(dict(user))

    response.set_cookie("access_token", access_token, max_age=ACCESS_TOKEN_EXPIRE_MINUTES, **COOKIE_OPTIONS)
    response.set_cookie("refresh_token", new_refresh_token, max_age=REFRESH_TOKEN_EXPIRE_MINUTES, **COOKIE_OPTIONS)

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }
