from fastapi import APIRouter, Depends, Cookie, Response
from fastapi.security import OAuth2PasswordRequestForm

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.conn import get_db

from .schema import CreateUser, Token
from .service import register_user, login_user, refresh_user_token


auth_router = APIRouter(prefix="/auth", tags=["auth"])


@auth_router.post("/register")
async def register(user: CreateUser, db: AsyncSession = Depends(get_db)):
    new_user = await register_user(user, db)
    return new_user


@auth_router.post("/login", response_model=Token)
async def login(response: Response, db: AsyncSession = Depends(get_db), form_data: OAuth2PasswordRequestForm = Depends()):
    user_token = await login_user(form_data, response, db)
    return user_token


@auth_router.post("/refresh")
async def refresh(response: Response, db: AsyncSession = Depends(get_db), refresh_token: str = Cookie(None)):
    new_tokens = await refresh_user_token(response, refresh_token, db)
    return new_tokens

@auth_router.get("/logout")
async def logout(response: Response):
    response.delete_cookie("access_token")
    response.delete_cookie("refresh_token")
    return {"msg": "Logged out successfully"}