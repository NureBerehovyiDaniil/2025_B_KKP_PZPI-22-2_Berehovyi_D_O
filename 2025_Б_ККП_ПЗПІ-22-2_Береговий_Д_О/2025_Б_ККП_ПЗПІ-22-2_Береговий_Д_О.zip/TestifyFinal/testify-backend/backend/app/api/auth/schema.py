import re

from pydantic import BaseModel, EmailStr, Field, field_validator

class CreateUser(BaseModel):
    email: EmailStr = Field(..., 
                            max_length=255,  
                            description="Valid email address used for login",
                            example="user@example.com")

    password: str = Field(..., 
                          min_length=8, 
                          max_length=100, 
                          description="Password used for login",
                          example="password")
    
    @field_validator("password")
    def validate_strong_password(cls, v):
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r"[a-z]", v):
            raise ValueError("Password must contain at least one lowercase letter")
        if not re.search(r"\d", v):
            raise ValueError("Password must contain at least one digit")
        if not re.search(r"[-_@#!?]", v):
            raise ValueError("Password must contain at least one special character")
        return v
    

class Token(BaseModel):
    access_token: str
    token_type: str
    refresh_token: str