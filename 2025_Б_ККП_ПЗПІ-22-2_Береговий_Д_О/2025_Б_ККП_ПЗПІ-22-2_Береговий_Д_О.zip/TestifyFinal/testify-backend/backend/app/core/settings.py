from pydantic_settings import BaseSettings
from pydantic import Field, SecretStr

class Settings(BaseSettings):
    """
    Application settings.
    """
    # Database settings

    # Redis settings

    # JWT settings
    SECRET_JWT_KEY: str 
    JWT_ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int 
    REFRESH_TOKEN_EXPIRE_MINUTES: int 
    
    DB_GATEWAY_URL: str
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        
settings = Settings()