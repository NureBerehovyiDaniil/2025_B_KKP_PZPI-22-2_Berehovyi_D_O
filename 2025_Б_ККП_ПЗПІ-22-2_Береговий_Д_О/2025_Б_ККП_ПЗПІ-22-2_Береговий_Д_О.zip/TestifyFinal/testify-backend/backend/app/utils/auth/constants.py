import os

SECRET_JWT_KEY = os.getenv("SECRET_JWT_KEY")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES"))
REFRESH_TOKEN_EXPIRE_MINUTES = int(os.getenv("REFRESH_TOKEN_EXPIRE_MINUTES"))

COOKIE_OPTIONS = {
    "httponly": True,
    "secure": True,
    "samesite": "lax",
    "path": "/",
}