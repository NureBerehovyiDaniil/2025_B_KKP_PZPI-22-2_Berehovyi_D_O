import os
import jwt
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi import HTTPException, status, Response, Depends

from app.database.models.User import User
from app.utils.queries.fetching import fetch_one_or_none
from app.database.conn import get_db
from .constants import SECRET_JWT_KEY, JWT_ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES, REFRESH_TOKEN_EXPIRE_MINUTES, COOKIE_OPTIONS


async def create_access_token(data: dict):
    to_encode = {"id": str(data["id"]), "email": data["email"], "username": data["username"]}
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_JWT_KEY, algorithm=JWT_ALGORITHM)
    return encoded_jwt


async def create_refresh_token(data: dict):
    to_encode = {"id": str(data["id"]), "email": data["email"], "username": data["username"]}
    expire = datetime.utcnow() + timedelta(minutes=REFRESH_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_JWT_KEY, algorithm=JWT_ALGORITHM)
    return encoded_jwt


async def get_user_from_token(token: str, db: AsyncSession = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    user_email = None
    try:
        payload = jwt.decode(token, key=SECRET_JWT_KEY, algorithms=[JWT_ALGORITHM])
        user_email: str = payload.get("email", None)

        if user_email is None:
            raise credentials_exception

    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired",
        )
    except jwt.PyJWTError:
        raise credentials_exception
    
    query = select(User).where(User.email == user_email)
    user = await fetch_one_or_none(db, query)
    if user is None:
        raise credentials_exception
    
    return user

