from uuid import UUID
from typing import List

from fastapi import Depends, Request, HTTPException
from fastapi.security import OAuth2PasswordBearer

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pydantic import BaseModel, EmailStr

from app.database.conn import get_db
from app.database.models.User import User

from app.utils.encryption.password import verify_password
from app.utils.queries.fetching import fetch_one_or_none
from app.utils.auth.token import get_user_from_token

class AuthUser(BaseModel):
    id: UUID
    email: EmailStr
    password: str
    username: str

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

from fastapi import Request

class Authorization:
    def __init__(self, allowed_roles: List[str] = []):
        self.allowed_roles = allowed_roles

    async def __call__(
        self,
        request: Request,
        db: AsyncSession = Depends(get_db),
    ):
        print(f"\033[91mCHECKING TOKEN\033[0m")

        # Try from Authorization header
        auth_header = request.headers.get("Authorization")
        token = None
        print(f"\033[91mA: {auth_header}\033[0m")

        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
        else:
            # Try from cookies

            token = request.cookies.get("access_token")

        if not token:
            raise HTTPException(
                status_code=401,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )

        user = await get_user_from_token(token, db)
        return user



async def authenticate_user(db, email: str = None, password: str = None) -> bool:
    query = select(User).where(User.email == email)
    user = await fetch_one_or_none(db, query)
    if not user or not verify_password(password, user.password):
        return None
    return AuthUser(id=str(user.id), email=user.email, password=user.password, username=user.username)
