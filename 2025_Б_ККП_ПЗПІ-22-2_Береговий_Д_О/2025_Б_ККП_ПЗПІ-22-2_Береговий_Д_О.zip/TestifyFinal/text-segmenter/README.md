# text-segmenter
Modular text segmentation library in Go. Implements TextTiling, C99, and topic-based (TextSeg) segmentation for large-scale text processing.This 
