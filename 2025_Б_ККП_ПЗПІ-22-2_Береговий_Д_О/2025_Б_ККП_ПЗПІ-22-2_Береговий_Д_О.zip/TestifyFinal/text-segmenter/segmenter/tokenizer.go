package segmenter

import (
	"strings"
)

// Tokenizer interface defines a method for tokenizing text.
type Tokenizer interface {
	Tokenize(text string) interface{}
}

// SimpleTokenizer is a basic implementation of the Tokenizer interface.
type SimpleTokenizer struct{}

// Tokenize split text into lowercase words by spaces.
func (t *SimpleTokenizer) Tokenize(text string) interface{} {
	return strings.Fields(strings.ToLower(text))
}
