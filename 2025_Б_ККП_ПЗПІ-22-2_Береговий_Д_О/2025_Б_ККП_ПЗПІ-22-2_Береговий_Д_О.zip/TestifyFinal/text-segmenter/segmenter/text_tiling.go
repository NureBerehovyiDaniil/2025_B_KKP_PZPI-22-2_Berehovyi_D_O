package segmenter

import (
	"math"
	"sort"
)

// TextTiling represents the text tiling algorithm.
type TextTiling struct {
	// Window (Optional) is the size of the window used to compute cosine similarity.
	// If not set, it will be calculated as 1/3 of the number of paragraphs.
	Window int
	// Tokenizer is the tokenizer used to split text into words.
	Tokenizer Tokenizer
}

// Segment segments the document into subtopic passages.
func (tt *TextTiling) Segment(paragraphs []string) []int {
	if len(paragraphs) == 0 {
		panic("paragraphs cannot be empty")
	}

	numParagraphs := len(paragraphs)

	if tt.Window <= 0 {
		tt.Window = int(math.Max(math.Min(float64(tt.Window), float64(numParagraphs)/3), 1))
	}

	tokenCounts := tt.tokenizeAndCount(paragraphs)
	gapScores := tt.calculateGapScores(tokenCounts)
	depthScores := tt.calculateDepthScores(gapScores)
	smoothedDepthScores := tt.smoothDepthScores(depthScores)
	boundaries := tt.determineBoundaries(smoothedDepthScores)

	return append([]int{1}, boundaries[:numParagraphs-1]...)
}

// tokenizeAndCount tokenizes and counts words in each paragraph.
func (tt *TextTiling) tokenizeAndCount(paragraphs []string) []map[string]int {
	numParagraphs := len(paragraphs)
	tokenCounts := make([]map[string]int, numParagraphs)
	for i, paragraph := range paragraphs {
		tokens := tt.Tokenizer.Tokenize(paragraph)
		tokenCounts[i] = countTokens(tokens)
	}
	return tokenCounts
}

// calculateGapScores computes the gap scores for each paragraph boundary.
func (tt *TextTiling) calculateGapScores(tokenCounts []map[string]int) []float64 {
	numParagraphs := len(tokenCounts)
	gapScores := make([]float64, numParagraphs)
	for i := 0; i < numParagraphs; i++ {
		windowSize := int(math.Min(math.Min(float64(i+1), float64(numParagraphs-i-1)), float64(tt.Window)))
		leftCounts, rightCounts := make(map[string]int), make(map[string]int)
		for j := i - windowSize + 1; j <= i; j++ {
			addCounts(leftCounts, tokenCounts[j])
		}
		for j := i + 1; j <= i+windowSize; j++ {
			addCounts(rightCounts, tokenCounts[j])
		}
		gapScores[i] = cosineSim(leftCounts, rightCounts)
	}
	return gapScores
}

// calculateDepthScores computes the depth scores from the gap scores.
func (tt *TextTiling) calculateDepthScores(gapScores []float64) []float64 {
	numParagraphs := len(gapScores)
	depthScores := make([]float64, numParagraphs)
	for i := 0; i < numParagraphs; i++ {
		if i < tt.Window || i+tt.Window >= numParagraphs {
			continue
		}
		leftVal, rightVal := findLeftVal(gapScores, i), findRightVal(gapScores, i)
		depthScores[i] = leftVal + rightVal - 2*gapScores[i]
	}
	return depthScores
}

// smoothDepthScores smooths the depth scores using a fixed window size of 3.
func (tt *TextTiling) smoothDepthScores(depthScores []float64) []float64 {
	numParagraphs := len(depthScores)
	smoothed := make([]float64, numParagraphs)
	for i := 0; i < numParagraphs; i++ {
		if i-1 < 0 || i+1 >= numParagraphs {
			smoothed[i] = depthScores[i]
		} else {
			smoothed[i] = average(depthScores[i-1 : i+2])
		}
	}
	return smoothed
}

// determineBoundaries determines the segment boundaries based on smoothed depth scores.
func (tt *TextTiling) determineBoundaries(smoothedDepthScores []float64) []int {
	numParagraphs := len(smoothedDepthScores)
	boundaries := make([]int, numParagraphs)
	mean, stdDev := meanAndStdDev(smoothedDepthScores)
	cutoff := mean - stdDev/2.0

	depthTuples := make([][2]float64, numParagraphs)
	for i, score := range smoothedDepthScores {
		depthTuples[i] = [2]float64{score, float64(i)}
	}
	sort.Slice(depthTuples, func(i, j int) bool {
		return depthTuples[i][0] > depthTuples[j][0]
	})

	for _, tuple := range depthTuples {
		if tuple[0] <= cutoff {
			break
		}
		index := int(tuple[1])
		boundaries[index] = 1
		for i := index - 4; i <= index+4; i++ {
			if i != index && i >= 0 && i < numParagraphs && boundaries[i] == 1 {
				boundaries[index] = 0
				break
			}
		}
	}
	return boundaries
}
