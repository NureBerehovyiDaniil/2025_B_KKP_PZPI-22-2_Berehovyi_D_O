package segmenter

import (
	"strings"
)

// Segmenter defines the interface for segmenting text into meaningful segments.
type Segmenter interface {
	// Segment takes a text string and returns a slice of segmented strings or an error.
	Segment(text string) ([]string, error)
}

type segmenter struct {
	Window int
}

// NewSegmenter creates a new instance of a segmenter with the specified window size.
func NewSegmenter(window int) Segmenter {
	return &segmenter{
		Window: window,
	}
}

// Segment divides the input text into segments based on sentence boundaries and text tiling.
func (s *segmenter) Segment(text string) ([]string, error) {
	sentences := s.splitIntoSentences(text)

	textTiling := TextTiling{
		Window:    4,
		Tokenizer: &SimpleTokenizer{},
	}

	boundaries := textTiling.Segment(sentences)

	segments, err := s.divideIntoSegments(sentences, boundaries)
	if err != nil {
		return nil, err
	}

	return segments, nil
}

// splitIntoSentences splits the input text into sentences using common sentence delimiters.
func (s *segmenter) splitIntoSentences(text string) []string {
	sentenceDelimiters := ".!?"
	var sentences []string
	var currentSentence strings.Builder

	for i, char := range text {
		currentSentence.WriteRune(char)
		if strings.ContainsRune(sentenceDelimiters, char) {
			// Check if the next character exists and is not a space
			if i+1 < len(text) && text[i+1] != ' ' {
				continue
			}
			sentences = append(sentences, strings.TrimSpace(currentSentence.String()))
			currentSentence.Reset()
		}
	}

	if currentSentence.Len() > 0 {
		sentences = append(sentences, strings.TrimSpace(currentSentence.String()))
	}

	return sentences
}

// divideIntoSegments divides the sentences into segments based on the provided boundaries.
// Returns a slice of segmented strings or an error if segmentation fails.
func (s *segmenter) divideIntoSegments(sentences []string, boundaries []int) ([]string, error) {
	var segments []string
	var currentSegment strings.Builder

	for i, sentence := range sentences {
		currentSegment.WriteString(sentence)
		if boundaries[i] == 1 {
			segments = append(segments, strings.TrimSpace(currentSegment.String()))
			currentSegment.Reset()
		}
	}

	if currentSegment.Len() > 0 {
		segments = append(segments, strings.TrimSpace(currentSegment.String()))
	}

	return segments, nil
}
