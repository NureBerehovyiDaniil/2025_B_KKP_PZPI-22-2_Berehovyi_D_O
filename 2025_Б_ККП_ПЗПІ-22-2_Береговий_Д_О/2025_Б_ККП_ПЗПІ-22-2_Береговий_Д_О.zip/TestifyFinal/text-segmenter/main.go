package main

import (
	"flag"
	"log"
	"net/http"
	"text-segmenter/handler"
	mgr "text-segmenter/manager"
)

func main() {
	namespace := flag.String("namespace", "testify", "Kubernetes namespace to use")
	image := flag.String("image", "question-builder:1.0.0", "Docker image for the job")
	port := flag.String("port", ":8080", "Port to listen on")
	questionStoreUrl := flag.String("question-store-url",
		"db-gateway.storage.svc.cluster.local:50051", "URL for the question store")
	keyStoreUrl := flag.String("key-store-url",
		"http://key-store-service.key-storage.svc.cluster.local:80", "URL for the key store")
	retryLimit := flag.Int("retry-limit", 2, "Retry limit for job execution")

	flag.Parse()

	manager, err := mgr.NewManager(*namespace, *image)
	if err != nil {
		log.Fatalf("Failed to create manager: %v", err)
	}

	manager.SetKeyStoreUrl(*keyStoreUrl)
	manager.SetQuestionStoreUrl(*questionStoreUrl)
	manager.SetRetryLimit(int32(*retryLimit))

	http.HandleFunc("/process", handler.ProcessHandler(manager))

	log.Printf("Listening on %s", *port)
	log.Fatal(http.ListenAndServe(*port, nil))
}
